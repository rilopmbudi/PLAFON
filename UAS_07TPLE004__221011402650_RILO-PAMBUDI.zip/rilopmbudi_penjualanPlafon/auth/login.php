<?php
session_start();
if(isset($_SESSION['user'])) header("Location: ../admin/dashboard.php");
$error = $_SESSION['error'] ?? null; 
unset($_SESSION['error']);
?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<title>Login - Plafon Kita</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
:root {
    --primary: #8B0000;
    --secondary: #FF6347;
    --bg: #f5f5f5;
    --card-bg: #fff;
    --text-dark: #333;
}

*{margin:0;padding:0;box-sizing:border-box;font-family:'Segoe UI',sans-serif;}

body{
    background: linear-gradient(135deg, var(--primary), #3F000D);
    display:flex;
    justify-content:center;
    align-items:center;
    height:100vh;
}

.box{
    background:var(--card-bg);
    padding:36px 32px;
    border-radius:14px;
    width:380px;
    box-shadow:0 12px 30px rgba(0,0,0,0.2);
    transition:transform 0.3s, box-shadow 0.3s;
}
.box:hover{
    transform:translateY(-5px);
    box-shadow:0 16px 40px rgba(0,0,0,0.25);
}

h2{
    color:var(--primary);
    text-align:center;
    margin-bottom:20px;
    font-size:24px;
    letter-spacing:1px;
}

.form-group{
    display:flex;
    flex-direction:column;
    width:100%;
    margin-bottom:16px;
}

.label{
    font-size:14px;
    color:var(--primary);
    margin-bottom:6px;
    font-weight:600;
}

.input{
    width:100%;
    padding:12px 14px;
    border-radius:8px;
    border:1px solid #b9b9b9;
    font-size:15px;
    outline:none;
    transition:all 0.3s;
}
.input:focus{
    border-color:var(--primary);
    box-shadow:0 0 0 3px rgba(139,0,0,0.15);
}

.btn{
    width:100%;
    padding:13px;
    border:none;
    border-radius:8px;
    background:var(--primary);
    color:#fff;
    font-size:16px;
    margin-top:8px;
    cursor:pointer;
    font-weight:600;
    transition:all 0.3s;
}
.btn:hover{
    background:var(--secondary);
    transform:translateY(-2px);
    box-shadow:0 6px 15px rgba(0,0,0,0.2);
}

.alert{
    padding:12px;
    background:#ffdddd;
    color:#900;
    border-radius:8px;
    margin-bottom:16px;
    text-align:center;
    font-size:14px;
}

.link{
    margin-top:16px;
    text-align:center;
    color:var(--primary);
    font-size:14px;
}
.link a{
    color:var(--primary);
    font-weight:600;
    text-decoration:none;
    transition:all 0.3s;
}
.link a:hover{
    text-decoration:underline;
    color:var(--secondary);
}

/* Responsive */
@media(max-width:480px){
    .box{width:90%;padding:24px;}
    h2{font-size:20px;}
}
</style>
</head>

<body>

<div class="box">
    <h2><i class="fas fa-lock"></i> Login Plafon Kita</h2>

    <?php if($error): ?>
        <div class="alert"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form action="login_process.php" method="post">
        <div class="form-group">
            <label class="label">Username</label>
            <input class="input" type="text" name="username" placeholder="Masukkan username" required>
        </div>

        <div class="form-group">
            <label class="label">Password</label>
            <input class="input" type="password" name="password" placeholder="Masukkan password" required>
        </div>

        <button class="btn" type="submit"><i class="fas fa-sign-in-alt"></i> Login</button>
    </form>

    <div class="link">
        Belum punya akun? <a href="register.php">Register</a>
    </div>
</div>

</body>
</html>
