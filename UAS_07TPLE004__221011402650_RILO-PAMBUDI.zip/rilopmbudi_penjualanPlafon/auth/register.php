<?php
session_start();
if(isset($_SESSION['user'])) header("Location: ../admin/dashboard.php");
$error = $_SESSION['error'] ?? null; 
$success = $_SESSION['success'] ?? null;
unset($_SESSION['error'], $_SESSION['success']);
?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Register - Plafon Kita</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
:root {
    --primary: #8B0000;
    --secondary: #FF6347;
    --bg: #f5f5f5;
    --card-bg: #fff;
    --text-dark: #333;
}
*{margin:0;padding:0;box-sizing:border-box;font-family:'Segoe UI',sans-serif;}

body{
    background: linear-gradient(135deg, var(--primary), #3F000D);
    display:flex;
    justify-content:center;
    align-items:center;
    height:100vh;
}

.box{
    background:var(--card-bg);
    padding:36px 32px;
    border-radius:14px;
    width:420px;
    box-shadow:0 12px 30px rgba(0,0,0,0.2);
    transition:transform 0.3s, box-shadow 0.3s;
}
.box:hover{
    transform:translateY(-5px);
    box-shadow:0 16px 40px rgba(0,0,0,0.25);
}

h2{
    color:var(--primary);
    text-align:center;
    margin-bottom:20px;
    font-size:24px;
    font-weight:700;
    letter-spacing:1px;
}

.form-group{
    display:flex;
    flex-direction:column;
    width:100%;
    margin-bottom:16px;
}

.label{
    font-size:14px;
    color:var(--primary);
    margin-bottom:6px;
    font-weight:600;
}

.input{
    width:100%;
    padding:12px 14px;
    border-radius:8px;
    border:1px solid #bbb;
    font-size:15px;
    outline:none;
    transition:all 0.3s;
}
.input:focus{
    border-color:var(--primary);
    box-shadow:0 0 0 3px rgba(139,0,0,0.15);
}

.btn{
    width:100%;
    padding:13px;
    border:none;
    border-radius:8px;
    background:var(--primary);
    color:#fff;
    font-size:16px;
    margin-top:8px;
    cursor:pointer;
    font-weight:600;
    transition:all 0.3s;
}
.btn:hover{
    background:var(--secondary);
    transform:translateY(-2px);
    box-shadow:0 6px 15px rgba(0,0,0,0.2);
}

.alert{
    padding:12px;
    border-radius:8px;
    margin-bottom:16px;
    text-align:center;
    font-size:14px;
}
.alert-err{background:#ffdddd;color:#900;}
.alert-success{background:#d4ffe0;color:#065f2c;}

.link{
    margin-top:16px;
    text-align:center;
    font-size:14px;
}
.link a{
    color:var(--primary);
    font-weight:600;
    text-decoration:none;
    transition:all 0.3s;
}
.link a:hover{
    color:var(--secondary);
    text-decoration:underline;
}

/* Responsive */
@media(max-width:480px){
    .box{width:90%;padding:24px;}
    h2{font-size:20px;}
}
</style>
</head>
<body>

<div class="box">
    <h2><i class="fas fa-user-plus"></i> Register Plafon Kita</h2>

    <?php if($error): ?>
        <div class="alert alert-err"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <?php if($success): ?>
        <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

<form action="register_process.php" method="post">
    <div class="form-group">
        <label class="label">Username</label>
        <input class="input" type="text" name="username" placeholder="Masukkan username" required>
    </div>

    <div class="form-group">
        <label class="label">Nama Lengkap</label>
        <input class="input" type="text" name="full_name" placeholder="Masukkan nama lengkap" required>
    </div>

    <div class="form-group">
        <label class="label">Password</label>
        <input class="input" type="password" name="password" placeholder="Masukkan password" required>
    </div>

    <div class="form-group">
        <label class="label">Role</label>
        <select class="input" name="role" required>
            <option value="" disabled selected>Pilih role pengguna</option>
            <option value="admin">Admin</option>
            <option value="manager">Manager</option>
            <option value="customer">Customer</option>
            <option value="direktur">Direktur</option>
        </select>
    </div>

    <button class="btn" type="submit"><i class="fas fa-user-check"></i> Register</button>
</form>



    <div class="link">
        Sudah punya akun? <a href="login.php">Login</a>
    </div>
</div>

</body>
</html>
