<?php
require_once __DIR__ . '/../config/koneksi.php';
session_start();

if($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: register.php");
    exit;
}

$username = trim($_POST['username']);
$full_name = trim($_POST['full_name']);
$password = $_POST['password'];
$role = $_POST['role']; // ❤️ ambil role dari form

if ($username === '' || $full_name === '' || $password === '' || $role === '') {
    $_SESSION['error'] = 'Semua field harus diisi';
    header('Location: register.php');
    exit;
}

// cek username
$stmt = $koneksi->prepare('SELECT id FROM users WHERE username = ?');
$stmt->bind_param('s', $username);
$stmt->execute();
$stmt->store_result();

if($stmt->num_rows > 0){
    $_SESSION['error'] = 'Username sudah dipakai';
    header('Location: register.php');
    exit;
}
$stmt->close();

$hash = password_hash($password, PASSWORD_DEFAULT);

$ins = $koneksi->prepare(
    'INSERT INTO users (username, full_name, password, role) VALUES (?, ?, ?, ?)'
);
$ins->bind_param('ssss', $username, $full_name, $hash, $role);

if($ins->execute()){
    $_SESSION['success'] = 'Registrasi berhasil. Silakan login.';
    header('Location: login.php');
    exit;
} else {
    $_SESSION['error'] = 'Gagal registrasi: ' . $koneksi->error;
    header('Location: register.php');
    exit;
}
