<?php
require_once __DIR__ . '/../config/koneksi.php';
session_start();

if($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: login.php");
    exit;
}

$username = trim($_POST['username']);
$password = $_POST['password'];

$stmt = $koneksi->prepare(
    "SELECT id, username, full_name, password, role FROM users WHERE username = ?"
);

$stmt->bind_param("s", $username);
$stmt->execute();
$res = $stmt->get_result();

if($res && $res->num_rows === 1) {

    $user = $res->fetch_assoc();

    if(password_verify($password, $user['password'])) {

        $_SESSION['user'] = [
            'id' => $user['id'],
            'username' => $user['username'],
            'full_name' => $user['full_name'],
            'role' => $user['role']
        ];

        // Redirect sesuai role
        if($user['role'] === 'admin') {
            header("Location: ../admin/dashboard.php");
        } elseif($user['role'] === 'manager') {
            header("Location: ../manager/dashboard.php");
        } else {
            header("Location: ../customer/dashboard.php");
        }
        exit;
    }
}

$_SESSION['error'] = "Username atau password salah";
header("Location: login.php");
exit;
?>
