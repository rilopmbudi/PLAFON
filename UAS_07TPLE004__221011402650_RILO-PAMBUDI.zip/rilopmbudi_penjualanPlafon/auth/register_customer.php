<?php
session_start();
require_once __DIR__ . '/../config/koneksi.php';

$error = $_SESSION['error'] ?? null;
$success = $_SESSION['success'] ?? null;
unset($_SESSION['error'], $_SESSION['success']);

if($_SERVER['REQUEST_METHOD'] === 'POST'){

    $nama = trim($_POST['nama']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    
    if($nama === "" || $email === "" || $password === ""){
        $_SESSION['error'] = "Semua field wajib diisi!";
        header("Location: register_customer.php");
        exit;
    }

    // Cek email
    $cek = $koneksi->prepare("SELECT id FROM customers WHERE email = ?");
    $cek->bind_param("s", $email);
    $cek->execute();
    $cek->store_result();

    if($cek->num_rows > 0){
        $_SESSION['error'] = "Email sudah digunakan!";
        header("Location: register_customer.php");
        exit;
    }

    // Hash password
    $hash = password_hash($password, PASSWORD_DEFAULT);

    // Simpan ke database
    $insert = $koneksi->prepare("INSERT INTO customers (nama, email, password) VALUES (?, ?, ?)");
    $insert->bind_param("sss", $nama, $email, $hash);

    if($insert->execute()){
        $_SESSION['success'] = "Registrasi berhasil! Silakan login.";
        header("Location: login_customer.php");
        exit;
    } else {
        $_SESSION['error'] = "Terjadi kesalahan: " . $koneksi->error;
        header("Location: register_customer.php");
        exit;
    }
}
