<?php
// config/koneksi.php
$DB_HOST = 'localhost';
$DB_USER = 'root';
$DB_PASS = '';
$DB_NAME = 'db_plafon';

$koneksi = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);
if ($koneksi->connect_error) {
    die("Koneksi error: " . $koneksi->connect_error);
}
$koneksi->set_charset("utf8mb4");
?>
