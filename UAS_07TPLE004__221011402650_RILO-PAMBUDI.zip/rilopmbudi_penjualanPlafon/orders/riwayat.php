<?php
session_start();
require_once __DIR__ . '/../config/koneksi.php';

if (!isset($_SESSION['user'])) {
    header("Location: ../auth/login.php");
    exit;
}

if ($_SESSION['user']['role'] !== 'customer') {
    header("Location: ../auth/login.php");
    exit;
}

$user = $_SESSION['user'];
$user_id = $user['id'];

/* --- CEK STRUKTUR TABEL ORDERS --- */
$columns_res = $koneksi->query("SHOW COLUMNS FROM orders");
$cols = [];
while ($c = $columns_res->fetch_assoc()) {
    $cols[] = $c['Field'];
}

// Auto deteksi kolom
$total_harga_col = in_array("total_harga", $cols) ? "o.total_harga" : "0 AS total_harga";
$created_at_col  = in_array("created_at", $cols) ? "o.created_at" : "NOW() AS created_at";

/* --- QUERY AMAN --- */
$sql = "
    SELECT 
        o.id,
        $total_harga_col,
        o.status,
        $created_at_col,
        (SELECT SUM(qty) FROM order_items WHERE order_id = o.id) AS total_item
    FROM orders o
    WHERE o.user_id = ?
    ORDER BY o.id DESC
";

$q = $koneksi->prepare($sql);

if (!$q) {
    die("<b>QUERY ERROR!</b><br>SQL: $sql<br>Error: " . $koneksi->error);
}

$q->bind_param("i", $user_id);
$q->execute();
$result = $q->get_result();
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Riwayat Pesanan</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
body{
    margin:0;
    background:#f1f1f1;
    font-family:"Segoe UI",sans-serif;
}

/* SIDEBAR */
.sidebar{
    width:230px;
    height:100vh;
    background:#8B0000;
    color:white;
    padding:20px;
    position:fixed;
    top:0; left:0;
}
.sidebar h2{ margin:0 0 20px; text-align:center; }
.sidebar a{
    display:block;
    padding:12px;
    margin-bottom:10px;
    color:white;
    text-decoration:none;
    border-radius:8px;
    transition:.3s;
}
.sidebar a:hover{ background:#A30000; }

/* CONTENT */
.content{
    margin-left:250px;
    padding:30px;
}

.box{
    background:white;
    padding:25px;
    border-radius:14px;
    box-shadow:0 4px 10px rgba(0,0,0,0.1);
}

/* HEADER */
.header-title{
    display:flex;
    align-items:center;
    gap:12px;
    margin-bottom:20px;
}
.header-title h2{
    margin:0;
    color:#8B0000;
}

/* TABLE */
table{
    width:100%;
    border-collapse:collapse;
}
th, td{
    border:1px solid #ddd;
    padding:12px;
    text-align:center;
}
th{
    background:#8B0000;
    color:white;
}

/* STATUS BADGES */
.status{
    padding:6px 12px;
    border-radius:8px;
    font-size:14px;
    color:white;
}
.pending{ background:#f39c12; }
.process{ background:#3498db; }
.send{ background:#8e44ad; }
.done{ background:#27ae60; }
.cancel{ background:#c0392b; }

/* BUTTON */
.btn{
    padding:6px 12px;
    border-radius:8px;
    background:#8B0000;
    color:white;
    text-decoration:none;
    margin-right:5px;
    display:inline-block;
}
.btn:hover{ background:#A30000; }

</style>

</head>
<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <h2>PLAFON KITA</h2>
    <p>Halo, <b><?= htmlspecialchars($user['full_name']) ?></b></p>

    <a href="../customer/dashboard.php"><i class="fa-solid fa-house"></i> Dashboard</a>
    <a href="../customer/produk.php"><i class="fa-solid fa-box"></i> Produk</a>
    <a href="../customer/keranjang.php"><i class="fa-solid fa-cart-shopping"></i> Keranjang</a>
    <a href="../customer/order_saya.php"><i class="fa-solid fa-receipt"></i> Pesanan Saya</a>
    <a href="riwayat.php" style="background:#660000;"><i class="fa-solid fa-clock-rotate-left"></i> Riwayat Pesanan</a>
    <a href="../auth/logout.php"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
</div>

<!-- CONTENT -->
<div class="content">
<div class="box">

    <div class="header-title">
        <i class="fa-solid fa-clock-rotate-left"></i>
        <h2>Riwayat Pesanan</h2>
    </div>

    <table>
        <tr>
            <th>ID Pesanan</th>
            <th>Total Item</th>
            <th>Total Harga</th>
            <th>Status</th>
            <th>Tanggal</th>
            <th>Aksi</th>
        </tr>

        <?php if ($result->num_rows == 0): ?>
        <tr>
            <td colspan="6" style="text-align:center;">Belum ada pesanan</td>
        </tr>
        <?php else: ?>
            <?php while($o = $result->fetch_assoc()): ?>

                <?php 
                $status = strtolower($o['status']);
                $badge = [
                    'pending' => 'pending',
                    'diproses' => 'process',
                    'dikirim' => 'send',
                    'selesai' => 'done',
                    'dibatalkan' => 'cancel'
                ][$status] ?? 'pending';
                ?>

                <tr>
                    <td>#<?= $o['id'] ?></td>
                    <td><?= $o['total_item'] ?> item</td>
                    <td>Rp <?= number_format($o['total_harga'], 0, ',', '.') ?></td>
                    <td><span class="status <?= $badge ?>"><?= ucfirst($o['status']) ?></span></td>
                    <td><?= $o['created_at'] ?></td>
                    <td>
                        <a href="detail.php?id=<?= $o['id'] ?>" class="btn">
                            <i class="fa-solid fa-eye"></i> Lihat
                        </a>
                    </td>
                </tr>

            <?php endwhile; ?>
        <?php endif; ?>
    </table>

</div>
</div>

</body>
</html>
