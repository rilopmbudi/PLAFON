<?php
require_once __DIR__ . '/../config/koneksi.php';
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: ../auth/login.php");
    exit;
}

// Pastikan hanya customer
if ($_SESSION['user']['role'] !== 'customer') {
    header("Location: ../admin/dashboard.php");
    exit;
}

$user_id = $_SESSION['user']['id'];

// Ambil semua pesanan berdasarkan customer
$stmt = $koneksi->prepare("
    SELECT * FROM orders 
    WHERE user_id = ? 
    ORDER BY id DESC
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<title>Pesanan Saya</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
:root {
    --primary: #8B0000;
    --secondary: #FF6347;
    --bg: #f5f5f5;
}

* { margin:0; padding:0; box-sizing:border-box; font-family:'Segoe UI', sans-serif; }

body {
    background: var(--bg);
    display: flex;
    min-height: 100vh;
}

/* SIDEBAR */
.sidebar {
    width: 240px;
    background: var(--primary);
    color: #fff;
    position: fixed;
    height: 100%;
    padding-top: 20px;
    display: flex;
    flex-direction: column;
    align-items: center;
}

.sidebar h2 {
    margin-bottom: 30px;
    font-size: 22px;
}

.sidebar a {
    width: 90%;
    padding: 12px 15px;
    margin-bottom: 10px;
    display: flex;
    align-items: center;
    color: #fff;
    border-radius: 8px;
    text-decoration: none;
    transition: 0.3s;
}

.sidebar a i { margin-right: 10px; }
.sidebar a:hover { background: var(--secondary); }

.content {
    margin-left: 240px;
    padding: 25px;
    width: calc(100% - 240px);
}

/* TABEL */
table {
    width: 100%;
    border-collapse: collapse;
    background: #fff;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 8px 20px rgba(0,0,0,0.08);
}

th, td {
    padding: 12px 15px;
    text-align: left;
}

th {
    background: var(--primary);
    color: #fff;
}

tr:nth-child(even) { background: #f9f9f9; }
tr:hover { background: #ffeaea; }

.badge {
    padding: 6px 10px;
    border-radius: 6px;
    color: #fff;
    font-size: 13px;
    font-weight: bold;
}

.badge.pending { background: #FFA500; }
.badge.proses { background: #007bff; }
.badge.kirim { background: #17a2b8; }
.badge.selesai { background: #28a745; }
.badge.batal { background: #dc3545; }

.btn-cancel {
    background: #dc3545;
    color: white;
    padding: 7px 12px;
    border-radius: 6px;
    text-decoration: none;
    font-size: 14px;
}
.btn-cancel:hover {
    background: #b52b36;
}

</style>
</head>
<body>

<!-- SIDEBAR CUSTOMER -->
<div class="sidebar">
    <h2>PLAFON KITA</h2>

    <a href="dashboard.php"><i class="fas fa-home"></i>Dashboard</a>
    <a href="../produk/produk_customer.php"><i class="fas fa-box"></i>Produk</a>
    <a href="keranjang.php"><i class="fas fa-shopping-cart"></i>Keranjang</a>
    <a href="order_saya.php"><i class="fas fa-file-invoice"></i>Pesanan Saya</a>
    <a href="profil.php"><i class="fas fa-user"></i>Profil</a>
    <a href="../auth/logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
</div>

<!-- KONTEN -->
<div class="content">
    <h1 style="color: var(--primary); margin-bottom:20px;">Pesanan Saya</h1>

    <table>
        <tr>
            <th>No</th>
            <th>Kode Pesanan</th>
            <th>Tanggal</th>
            <th>Total</th>
            <th>Status</th>
            <th>Aksi</th>
        </tr>

        <?php 
        $no = 1;
        while ($d = $result->fetch_assoc()):
            
            // Badge status
            $statusClass = [
                'pending' => 'pending',
                'diproses' => 'proses',
                'dikirim' => 'kirim',
                'selesai' => 'selesai',
                'dibatalkan' => 'batal'
            ][$d['status']] ?? 'pending';

        ?>
        <tr>
            <td><?= $no++ ?></td>
            <td><?= htmlspecialchars($d['kode_order']) ?></td>
            <td><?= date('d-m-Y H:i', strtotime($d['tanggal'])) ?></td>
            <td>Rp <?= number_format($d['total'], 0, ',', '.') ?></td>
            <td><span class="badge <?= $statusClass ?>"><?= ucfirst($d['status']) ?></span></td>
            <td>

                <a href="order_view.php?id=<?= $d['id'] ?>" class="btn-detail" 
                   style="background:#FF6347;color:white;padding:7px 12px;border-radius:6px;text-decoration:none;">
                   <i class="fas fa-eye"></i> Detail
                </a>

                <?php if ($d['status'] == 'pending'): ?>
                    <a href="order_cancel.php?id=<?= $d['id'] ?>" 
                       class="btn-cancel"
                       onclick="return confirm('Yakin ingin membatalkan pesanan?')">
                       Batalkan
                    </a>
                <?php endif; ?>

            </td>
        </tr>
        <?php endwhile; ?>

    </table>
</div>

</body>
</html>
