<?php
require_once __DIR__ . '/../config/koneksi.php';
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: ../auth/login.php");
    exit;
}

$order_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$order = $koneksi->prepare("
    SELECT o.*, u.full_name
    FROM orders o
    JOIN users u ON u.id = o.user_id
    WHERE o.id = ?
");
$order->bind_param("i", $order_id);
$order->execute();
$dataOrder = $order->get_result()->fetch_assoc();

if (!$dataOrder) {
    echo "<h2>Order tidak ditemukan!</h2>";
    exit;
}

// AUTO-DETECT FIELD
$tanggal = $dataOrder['created_at'] ?? 
           $dataOrder['tanggal'] ?? 
           $dataOrder['date'] ?? 
           "-";

$total_harga = $dataOrder['total_harga'] ??
               $dataOrder['total'] ??
               $dataOrder['grand_total'] ??
               0;

$item = $koneksi->prepare("
    SELECT oi.*, p.nama, p.harga
    FROM order_items oi
    JOIN produk p ON p.id = oi.produk_id
    WHERE oi.order_id = ?
");
$item->bind_param("i", $order_id);
$item->execute();
$listItem = $item->get_result();
?>
<!DOCTYPE html>
<html>
<head>
<title>Detail Pesanan</title>
<style>
body{font-family:Arial;background:#eef0f4;padding:25px;}
.box{
    max-width:900px;margin:auto;background:#fff;padding:25px;
    border-radius:14px;box-shadow:0 4px 15px rgba(0,0,0,0.1);
    animation: fadeIn .5s ease;
}
@keyframes fadeIn { from{opacity:0;transform:translateY(10px);} to{opacity:1;transform:translateY(0);} }
h2{color:#8B0000;margin-bottom:10px;text-align:center;}
.info{
    padding:15px;background:#fafafa;border-radius:10px;
    border:1px solid #ddd;margin-bottom:20px;
    line-height:1.7;
}
.info b{color:#8B0000;}
table{width:100%;border-collapse:collapse;margin-top:15px;}
th,td{padding:12px;border:1px solid #ddd;text-align:center;}
th{background:#8B0000;color:white;}
.btn{
    display:inline-block;margin-top:20px;padding:10px 15px;
    background:#8B0000;color:white;text-decoration:none;border-radius:8px;
    transition:.3s;
}
.btn:hover{background:#5a0000;}
</style>
</head>
<body>

<div class="box">
    <h2>Detail Pesanan #<?= $dataOrder['id'] ?></h2>

    <div class="info">
        <p><b>Pemesan:</b> <?= $dataOrder['full_name'] ?></p>
        <p><b>Tanggal Pesan:</b> <?= $tanggal ?></p>
        <p><b>Total Harga:</b> Rp <?= number_format($total_harga,0,',','.') ?></p>
    </div>

    <h3 style="color:#8B0000;margin-top:20px;">Daftar Barang</h3>

    <table>
        <tr>
            <th>Nama Produk</th>
            <th>Qty</th>
            <th>Harga</th>
            <th>Subtotal</th>
        </tr>

        <?php 
        while($i = $listItem->fetch_assoc()):
            $sub = $i['qty'] * $i['harga'];
        ?>
        <tr>
            <td><?= $i['nama'] ?></td>
            <td><?= $i['qty'] ?></td>
            <td>Rp <?= number_format($i['harga'],0,',','.') ?></td>
            <td>Rp <?= number_format($sub,0,',','.') ?></td>
        </tr>
        <?php endwhile; ?>
    </table>

    <a href="riwayat.php" class="btn">Kembali</a>
</div>

</body>
</html>
