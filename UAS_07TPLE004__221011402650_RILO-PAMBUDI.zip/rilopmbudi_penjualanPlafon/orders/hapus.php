<?php
require_once __DIR__ . '/../config/koneksi.php';
session_start();

// Pastikan user login
if (!isset($_SESSION['user'])) {
    header("Location: ../auth/login.php");
    exit;
}

$user_id = $_SESSION['user']['id'];

// Ambil ID pesanan
if (!isset($_GET['id'])) {
    header("Location: riwayat.php?error=invalid");
    exit;
}

$order_id = (int)$_GET['id'];

// Cek apakah order milik user ini
$cek = $koneksi->prepare("
    SELECT id, status FROM orders 
    WHERE id = ? AND user_id = ?
");
$cek->bind_param("ii", $order_id, $user_id);
$cek->execute();
$result = $cek->get_result();

if ($result->num_rows === 0) {
    header("Location: riwayat.php?error=notfound");
    exit;
}

$data = $result->fetch_assoc();

if (strtolower($data['status']) !== "proses") {
    header("Location: riwayat.php?error=cannot_cancel");
    exit;
}

// Update status menjadi batal
$update = $koneksi->prepare("
    UPDATE orders
    SET status = 'batal'
    WHERE id = ? AND user_id = ?
");
$update->bind_param("ii", $order_id, $user_id);
$update->execute();

// Kembali ke riwayat
header("Location: riwayat.php?success=batal");
exit;

?>
