<?php
require_once __DIR__ . '/../config/koneksi.php';
session_start();

// Cek login
if(!isset($_SESSION['user'])){
    header("Location: ../auth/login.php");
    exit;
}

$user_id = $_SESSION['user']['id'] ?? 0;
$order_id = intval($_GET['id'] ?? 0);

// Ambil data pesanan customer
$orderQuery = $koneksi->query("SELECT * FROM orders WHERE id=$order_id AND user_id=$user_id");
if(!$orderQuery || $orderQuery->num_rows == 0){
    die("Pesanan tidak ditemukan atau Anda tidak berhak mengaksesnya.");
}
$order = $orderQuery->fetch_assoc();

// Handle cancel pesanan
if(isset($_POST['cancel'])){
    if($order['status'] == 'pending'){
        $update = $koneksi->query("UPDATE orders SET status='batal' WHERE id=$order_id");
        if($update){
            header("Location: ../customer/orders.php");
            exit;
        } else {
            $error = "Gagal membatalkan pesanan: " . $koneksi->error;
        }
    } else {
        $error = "Pesanan tidak dapat dibatalkan.";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Detail Pesanan #<?= $order_id ?> - PLAFON KITA</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
body{font-family:Arial;background:#f5f5f5;padding:20px;}
.container{max-width:600px;margin:auto;background:#fff;padding:20px;border-radius:12px;box-shadow:0 0 10px rgba(0,0,0,0.1);}
h2{text-align:center;color:#8B0000;margin-bottom:20px;}
.card{background:#fdfdfd;padding:15px;border-radius:10px;margin-bottom:15px;box-shadow:0 3px 10px rgba(0,0,0,0.05);}
p{margin:8px 0;}
.status{font-weight:bold;padding:5px 10px;border-radius:5px;color:#fff;}
.status-pending{background:#ffc107;}
.status-proses{background:#17a2b8;}
.status-selesai{background:#28a745;}
.status-batal{background:#dc3545;}
button{padding:10px 15px;background:#dc3545;color:#fff;border:none;border-radius:6px;cursor:pointer;transition:0.3s;}
button:hover{background:#c82333;}
.back-link{display:inline-block;margin-top:15px;color:#8B0000;text-decoration:none;font-weight:bold;}
.back-link:hover{color:#FF6347;}
.error{color:red;font-weight:bold;}
</style>
</head>
<body>

<div class="container">
    <h2>Detail Pesanan #<?= $order_id ?></h2>

    <?php if(isset($error)): ?>
        <p class="error"><?= $error ?></p>
    <?php endif; ?>

    <div class="card">
        <p><strong>Tanggal:</strong> <?= $order['tanggal'] ?></p>
        <p><strong>Status:</strong> 
            <?php
            $statusClass = strtolower($order['status']);
            echo '<span class="status status-'.$statusClass.'">'.ucfirst($order['status']).'</span>';
            ?>
        </p>
        <p><strong>Total:</strong> Rp <?= number_format($order['total'],0,',','.') ?></p>
    </div>

    <?php if($order['status'] == 'pending'): ?>
    <form method="post">
        <button type="submit" name="cancel"><i class="fas fa-times"></i> Batalkan Pesanan</button>
    </form>
    <?php endif; ?>

    <a class="back-link" href="orders.php"><i class="fas fa-arrow-left"></i> Kembali ke Daftar Pesanan</a>
</div>

</body>
</html>
