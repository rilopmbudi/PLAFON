<?php
require_once __DIR__ . '/../config/koneksi.php';
session_start();
if(!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'manager') {
    header('Location: ../auth/login.php');
    exit;
}

// Ambil semua pelanggan
$q = $koneksi->query("SELECT * FROM users WHERE role='customer' ORDER BY id DESC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Daftar Pelanggan - PLAFON KITA</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
:root {
    --primary: #8B0000;
    --secondary: #FF6347;
    --bg: #f5f5f5;
    --card-bg: #fff;
    --text-dark: #333;
}
*{margin:0;padding:0;box-sizing:border-box;font-family:'Segoe UI',sans-serif}
body{background:var(--bg);display:flex;min-height:100vh;}

/* SIDEBAR */
.sidebar{
    width:240px;background:var(--primary);color:#fff;position:fixed;height:100%;
    display:flex;flex-direction:column;align-items:center;padding-top:20px;transition:width 0.3s;
}
.sidebar h2{text-align:center;margin-bottom:30px;font-size:22px;letter-spacing:1px}
.sidebar a{
    display:flex;align-items:center;width:90%;padding:12px 15px;
    color:#fff;text-decoration:none;margin-bottom:10px;border-radius:8px;
    transition:0.3s;
}
.sidebar a:hover{background:var(--secondary);color:#fff;}
.sidebar a i{margin-right:10px;}

/* CONTENT */
.content{margin-left:240px;padding:25px;flex:1;}
h1{color:var(--primary);margin-bottom:20px;}

/* Tombol Kembali kecil panah */
.back-btn{
    display:inline-flex;align-items:center;justify-content:center;
    width:35px;height:35px;margin-bottom:15px;
    background:var(--primary);color:white;
    border-radius:50%;text-decoration:none;font-size:16px;
    transition:0.3s;
}
.back-btn:hover{
    background:#a30000;
    transform:translateX(-2px);
}

/* Table */
.table-container{
    background:white;padding:20px;border-radius:12px;
    box-shadow:0 8px 20px rgba(0,0,0,0.08);
    overflow-x:auto;
}
.table{
    width:100%;
    border-collapse:collapse;
    margin-top:10px;
}
.table th, .table td{
    border:1px solid #ddd;padding:12px;text-align:left;
}
.table th{background:var(--primary);color:white;}
.table tr:hover{background:#fff2f2;}
</style>
</head>
<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <h2>PLAFON KITA</h2>

    <a href="dashboard.php">
        <i class="fas fa-tachometer-alt"></i>Dashboard
    </a>

    <a href="produk.php">
        <i class="fas fa-box"></i>Produk
    </a>

    <a href="orders.php">
        <i class="fas fa-receipt"></i>Pesanan
    </a>

    <a href="customers.php" style="background:var(--secondary);">
        <i class="fas fa-users"></i>Pelanggan
    </a>

    <a href="../auth/logout.php">
        <i class="fas fa-sign-out-alt"></i>Logout
    </a>
</div>

<!-- CONTENT -->
<div class="content">
    <a href="dashboard.php" class="back-btn" title="Kembali ke Dashboard">
        <i class="fas fa-arrow-left"></i>
    </a>

    <h1>Daftar Pelanggan</h1>

    <div class="table-container">
        <table class="table">
            <tr>
                <th>No</th>
                <th>Username</th>
                <th>Nama Lengkap</th>
                <th>Tanggal Daftar</th>
            </tr>

            <?php $no=1; while($r=$q->fetch_assoc()): ?>
            <tr>
                <td><?= $no++ ?></td>
                <td><?= htmlspecialchars($r['username']) ?></td>
                <td><?= htmlspecialchars($r['full_name']) ?></td>
                <td><?= date("d-m-Y H:i", strtotime($r['created_at'])) ?></td>
            </tr>
            <?php endwhile; ?>
            <?php if($q->num_rows == 0): ?>
            <tr>
                <td colspan="4" style="text-align:center;">Tidak ada pelanggan</td>
            </tr>
            <?php endif; ?>
        </table>
    </div>
</div>

</body>
</html>
