<?php
require_once __DIR__ . '/../config/koneksi.php';
session_start();
if(!isset($_SESSION['user'])) header('Location: ../auth/login.php');

$id = intval($_GET['id'] ?? 0);
$koneksi->query("DELETE FROM customers WHERE id=$id");
header("Location: customer.php");
exit;
