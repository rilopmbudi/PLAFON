<?php
require_once __DIR__ . '/../config/koneksi.php';
session_start();

// Cek login admin
if(!isset($_SESSION['user'])){
    header("Location: ../auth/login.php");
    exit;
}

// Ambil data pesanan beserta nama customer
$q = $koneksi->query("
    SELECT o.*, u.username AS customer_name
    FROM orders o
    LEFT JOIN users u ON o.user_id = u.id
    ORDER BY o.tanggal DESC
");

// Statistik card
$totalOrders    = intval($koneksi->query("SELECT COUNT(*) AS c FROM orders")->fetch_assoc()['c']);
$totalCustomers = intval($koneksi->query("SELECT COUNT(*) AS c FROM users WHERE role='customer'")->fetch_assoc()['c']);
$totalProducts  = intval($koneksi->query("SELECT COUNT(*) AS c FROM produk")->fetch_assoc()['c']);
?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<title>Daftar Pesanan - PLAFON KITA</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
:root {
    --primary: #8B0000;
    --secondary: #FF6347;
    --success: #28a745;
    --danger: #dc3545;
    --pending: #ffc107;
    --bg: #f5f5f5;
    --card-bg: #fff;
    --text-dark: #333;
}
*{margin:0;padding:0;box-sizing:border-box;font-family:'Segoe UI',sans-serif}
body{display:flex;background:var(--bg);min-height:100vh;}

/* Sidebar sama persis seperti dashboard */
.sidebar{
    width:240px;background:var(--primary);color:#fff;height:100%;position:fixed;
    display:flex;flex-direction:column;align-items:center;padding-top:20px;
}
.sidebar h2{text-align:center;margin-bottom:30px;font-size:22px;letter-spacing:1px;}
.sidebar a{
    display:flex;align-items:center;width:90%;padding:12px 15px;
    color:#fff;text-decoration:none;margin-bottom:10px;border-radius:8px;
    transition:all 0.3s ease;
}
.sidebar a i{margin-right:10px;}
.sidebar a:hover{background:var(--secondary);transform:translateX(5px);}

/* Content */
.content{margin-left:240px;padding:25px;flex:1}
h1{color:var(--primary);margin-bottom:20px;text-align:center;}

/* Statistik card */
.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:15px;margin-bottom:20px;}
.card{background:var(--card-bg);padding:15px;border-radius:12px;box-shadow:0 6px 18px rgba(0,0,0,0.08);transition:0.3s;display:flex;align-items:center;justify-content:space-between;}
.card:hover{transform:translateY(-5px);}
.card .icon{font-size:28px;color:var(--secondary);transition:transform 0.3s;}
.card:hover .icon{transform:rotate(15deg);}
.card-info{display:flex;flex-direction:column;text-align:right;}
.card-info h3{color:var(--primary);font-size:22px;margin-bottom:5px;}
.card-info p{color:var(--text-dark);font-size:14px;}

/* Tabel pesanan */
.table-container{overflow-x:auto;margin-top:20px;}
table{width:100%;border-collapse:collapse;background:var(--card-bg);border-radius:8px;overflow:hidden;box-shadow:0 6px 18px rgba(0,0,0,0.08);transition:0.3s;}
table:hover{transform:translateY(-2px);}
th, td{padding:12px;text-align:left;}
th{background:var(--primary);color:#fff;}
tr:nth-child(even){background:#f9f9f9;}
tr:hover{background:#f1e6e6;transition:0.3s;}

/* Status badge */
.status {
    padding:4px 8px;
    border-radius:6px;
    color:#fff;
    font-weight:600;
    font-size:13px;
    display:inline-block;
    text-transform:capitalize;
}
.status-pending { background: var(--pending); color:#000; }
.status-proses   { background: var(--secondary); }
.status-selesai  { background: var(--success); }
.status-batal    { background: var(--danger); }

/* Tombol */
.btn-view{display:inline-block;padding:6px 10px;background:var(--primary);color:#fff;text-decoration:none;border-radius:6px;transition:0.3s;margin-right:4px;}
.btn-view:hover{background:var(--secondary);transform:translateY(-2px);}
.btn-approve{display:inline-block;padding:6px 10px;background:var(--success);color:#fff;text-decoration:none;border-radius:6px;transition:0.3s;margin-right:4px;}
.btn-approve:hover{background:#218838;}
.btn-reject{display:inline-block;padding:6px 10px;background:var(--danger);color:#fff;text-decoration:none;border-radius:6px;transition:0.3s;}
.btn-reject:hover{background:#c82333;}
.back-link{display:inline-block;margin-top:15px;color:var(--primary);text-decoration:none;font-weight:bold;transition:0.3s;}
.back-link:hover{color:var(--secondary);text-decoration:underline;}

/* Responsive */
@media screen and (max-width:768px){.sidebar{width:200px}.content{margin-left:200px}}
@media screen and (max-width:500px){th,td{padding:8px;font-size:13px}.btn-view,.btn-approve,.btn-reject{padding:5px 8px;font-size:13px}}
</style>
</head>
<body>

<div class="sidebar">
    <h2>PLAFON KITA</h2>
    <a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
    <a href="produk.php"><i class="fas fa-box"></i> Produk</a>
    <a href="orders.php" style="background:var(--secondary);"><i class="fas fa-receipt"></i> Pesanan</a>
    <a href="customers.php"><i class="fas fa-users"></i> Pelanggan</a>
    <a href="../auth/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
</div>

<div class="content">
    <h1>Daftar Pesanan</h1>

    <!-- Card Statistik -->
    <div class="stats">
        <div class="card">
            <div class="icon"><i class="fas fa-box"></i></div>
            <div class="card-info">
                <h3><?= $totalProducts ?></h3>
                <p>Jumlah Produk</p>
            </div>
        </div>
        <div class="card">
            <div class="icon"><i class="fas fa-receipt"></i></div>
            <div class="card-info">
                <h3><?= $totalOrders ?></h3>
                <p>Total Pesanan</p>
            </div>
        </div>
        <div class="card">
            <div class="icon"><i class="fas fa-users"></i></div>
            <div class="card-info">
                <h3><?= $totalCustomers ?></h3>
                <p>Pelanggan</p>
            </div>
        </div>
    </div>

    <!-- Tabel pesanan -->
    <div class="table-container card">
        <table>
            <tr>
                <th>No</th>
                <th>Order ID</th>
                <th>Pelanggan</th>
                <th>Tanggal</th>
                <th>Status</th>
                <th>Total</th>
                <th>Aksi</th>
            </tr>
            <?php $no=1; while($r = $q->fetch_assoc()): 
                $status = strtolower(trim($r['status'] ?? 'pending'));
            ?>
            <tr>
                <td><?= $no++ ?></td>
                <td><?= htmlspecialchars($r['id']) ?></td>
                <td><?= htmlspecialchars($r['customer_name'] ?? 'Umum') ?></td>
                <td><?= $r['tanggal'] ?></td>
                <td><span class="status status-<?= $status ?>"><?= ucfirst($status) ?></span></td>
                <td>Rp <?= number_format($r['total'],0,',','.') ?></td>
                <td>
                    <a class="btn-view" href="order_view.php?id=<?= $r['id'] ?>"><i class="fas fa-eye"></i> Lihat</a>
                    <?php if($status=='pending'): ?>
                        <a class="btn-approve" href="order_action.php?id=<?= $r['id'] ?>&action=approve"><i class="fas fa-check"></i> Approve</a>
                        <a class="btn-reject" href="order_action.php?id=<?= $r['id'] ?>&action=reject"><i class="fas fa-times"></i> Reject</a>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>
    </div>

    <a class="back-link" href="dashboard.php">← Kembali ke Dashboard</a>
</div>

</body>
</html>
