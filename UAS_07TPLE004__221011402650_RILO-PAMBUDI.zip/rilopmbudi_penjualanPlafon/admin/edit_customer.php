<?php
require_once __DIR__ . '/../config/koneksi.php';
session_start();
if(!isset($_SESSION['user'])) header('Location: ../auth/login.php');

$id = intval($_GET['id'] ?? 0);
$customer = $koneksi->query("SELECT * FROM customers WHERE id=$id")->fetch_assoc();
if(!$customer) die("Customer tidak ditemukan.");

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $code = $koneksi->real_escape_string($_POST['code']);
    $name = $koneksi->real_escape_string($_POST['name']);
    $phone = $koneksi->real_escape_string($_POST['phone']);
    $address = $koneksi->real_escape_string($_POST['address']);

    $stmt = $koneksi->prepare("UPDATE customers SET code=?, name=?, phone=?, address=? WHERE id=?");
    $stmt->bind_param("ssssi", $code, $name, $phone, $address, $id);
    $stmt->execute();

    header("Location: customer.php");
    exit;
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Edit Customer</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
body{font-family:Arial;background:#fdf6f6;margin:0;padding:0;}
.container{max-width:400px;margin:40px auto;background:#fff;padding:25px;border-radius:10px;box-shadow:0 6px 18px rgba(0,0,0,0.1);}
h2{text-align:center;color:maroon;margin-bottom:20px;}
form label{font-weight:bold;margin-bottom:5px;display:block;color:#333;}
form input{width:100%;padding:10px;margin-bottom:12px;border:1px solid #ccc;border-radius:6px;font-size:14px;box-sizing:border-box;}
form input:focus{border-color:maroon;outline:none;box-shadow:0 0 5px rgba(128,0,0,0.3);}
button{width:100%;padding:12px;background:maroon;color:#fff;border:none;border-radius:6px;font-size:16px;cursor:pointer;transition:background 0.3s;}
button:hover{background:#800000;}
.back-link{display:block;text-align:center;margin-top:15px;color:maroon;text-decoration:none;font-weight:bold;}
.back-link:hover{text-decoration:underline;}
</style>
</head>
<body>
<div class="container">
<h2>Edit Customer</h2>
<form method="post">
    <label>Kode Customer</label>
    <input name="code" value="<?= htmlspecialchars($customer['code']) ?>" required>

    <label>Nama</label>
    <input name="name" value="<?= htmlspecialchars($customer['name']) ?>" required>

    <label>Telepon</label>
    <input name="phone" value="<?= htmlspecialchars($customer['phone']) ?>" required>

    <label>Alamat</label>
    <input name="address" value="<?= htmlspecialchars($customer['address']) ?>" required>

    <button type="submit">Simpan Perubahan</button>
</form>
<a class="back-link" href="customer.php">← Kembali ke Data Customer</a>
</div>
</body>
</html>
