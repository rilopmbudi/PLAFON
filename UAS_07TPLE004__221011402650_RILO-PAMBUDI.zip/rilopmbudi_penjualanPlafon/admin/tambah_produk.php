<?php
session_start();
require_once __DIR__ . '/../config/koneksi.php';

// Cek login & role admin
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: ../auth/login.php");
    exit;
}

// ===============================================
// Ambil daftar produk untuk datalist (opsional)
// ===============================================
$products = [];
$res = $koneksi->query("SELECT sku, name FROM produk ORDER BY name ASC");
if ($res && $res->num_rows > 0) {
    while($row = $res->fetch_assoc()){
        $products[] = $row;
    }
}

// ===============================================
// Proses Submit Tambah Produk
// ===============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $sku = $_POST['sku'];
    $name = $_POST['name'];
    $category = $_POST['category'];
    $price = floatval($_POST['price']);
    $stock = intval($_POST['stock']);

    // ---- Proses Upload Foto ----
    $fotoName = null;
    if (!empty($_FILES['foto']['name'])) {
        $ext = pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION);
        $fotoName = "produk_" . time() . "_" . rand(100,999) . "." . $ext;
        move_uploaded_file($_FILES['foto']['tmp_name'], "../uploads/" . $fotoName);
    }

    // ---- Insert ke database ----
    $stmt = $koneksi->prepare("
        INSERT INTO produk (nama, deskripsi, harga, stok, gambar)
        VALUES (?, ?, ?, ?, ?)
    ");
    $stmt->bind_param("ssdis", $name, $category, $price, $stock, $fotoName);
    $stmt->execute();

    header("Location: produk.php");
    exit;
}
?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<title>Tambah Produk - PLAFON KITA</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
:root {
    --primary: #8B0000;
    --secondary: #FF6347;
    --bg: #f5f5f5;
    --card-bg: #fff;
    --text-dark: #333;
}
*{margin:0;padding:0;box-sizing:border-box;font-family:'Segoe UI',sans-serif;}
body{background:var(--bg);display:flex;min-height:100vh;}

/* Sidebar */
.sidebar{
    width:240px;background:var(--primary);color:#fff;position:fixed;height:100%;
    display:flex;flex-direction:column;align-items:center;padding-top:20px;transition:width 0.3s;
}
.sidebar h2{text-align:center;margin-bottom:30px;font-size:22px;letter-spacing:1px;}
.sidebar a{
    display:flex;align-items:center;width:90%;padding:12px 15px;
    color:#fff;text-decoration:none;margin-bottom:10px;border-radius:8px;
    transition:0.3s;
}
.sidebar a:hover{background:var(--secondary);}
.sidebar a i{margin-right:10px;}

/* Content */
.content{margin-left:240px;padding:25px;flex:1;}
.card{background:var(--card-bg);padding:25px;border-radius:12px;box-shadow:0 6px 18px rgba(0,0,0,0.08);}
.card input, .card select{width:100%;padding:12px;margin-bottom:12px;border-radius:8px;border:1px solid #ccc;}
button{width:100%;padding:12px;background:var(--primary);color:#fff;border:none;border-radius:8px;cursor:pointer;}
button:hover{background:#600000;}
h1{color:var(--primary);margin-bottom:20px;}
</style>
</head>
<body>

<div class="sidebar">
    <h2>PLAFON KITA</h2>
    <a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
    <a href="produk.php"><i class="fas fa-box"></i> Data Produk</a>
    <a href="tambah_produk.php" style="background:var(--secondary);"><i class="fas fa-plus"></i> Tambah Produk</a>
    <a href="orders.php"><i class="fas fa-receipt"></i> Pesanan</a>
    <a href="customers.php"><i class="fas fa-users"></i> Pelanggan</a>
    <a href="../auth/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
</div>

<div class="content">
    <h1>Tambah Produk Baru</h1>

    <div class="card">
        <form method="POST" enctype="multipart/form-data">
            <label>Nama Produk</label>
            <input name="name" list="name-list" required>
            <datalist id="name-list">
                <?php foreach($products as $p): ?>
                    <option value="<?= htmlspecialchars($p['name']) ?>"></option>
                <?php endforeach; ?>
            </datalist>

            <label>Kategori / Deskripsi</label>
            <input name="category" required>

            <label>Harga</label>
            <input type="number" name="price" required>

            <label>Stok</label>
            <input type="number" name="stock" required>

            <label>Upload Foto Produk</label>
            <input type="file" name="foto" accept="image/*">

            <button type="submit"><i class="fa fa-save"></i> Simpan Produk</button>
        </form>
    </div>
</div>

</body>
</html>
