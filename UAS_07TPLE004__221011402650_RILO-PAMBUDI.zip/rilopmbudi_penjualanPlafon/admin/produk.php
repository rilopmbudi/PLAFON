<?php
require_once __DIR__ . '/../config/koneksi.php';
session_start();

// Cek login admin
if(!isset($_SESSION['user'])){
    header("Location: ../auth/login.php");
    exit;
}

$cekProduk = $koneksi->query("SELECT COUNT(*) AS c FROM produk")->fetch_assoc();
if($cekProduk['c'] == 0){
    $koneksi->query("
        INSERT INTO produk (nama, deskripsi, harga, stok, gambar) VALUES
        ('Plafon Minimalis Putih', 'Plafon minimalis untuk rumah modern', 500000, 10, 'plafon1.png'),
        ('Plafon Kayu Natural', 'Plafon kayu dengan finishing natural', 750000, 5, 'plafon2.png'),
        ('Plafon PVC Motif', 'Plafon PVC dengan motif elegan', 350000, 20, 'plafon3.png'),
        ('Plafon Gypsum Elegan', 'Plafon gypsum desain elegan', 650000, 8, 'plafon4.png'),
        ('Plafon Kayu Jati', 'Plafon kayu jati berkualitas', 900000, 3, 'plafon5.png'),
        ('Plafon PVC Polos', 'Plafon PVC polos praktis', 300000, 15, 'plafon6.png'),
        ('Plafon Minimalis Abu', 'Plafon minimalis warna abu-abu', 520000, 12, 'plafon7.png'),
        ('Plafon Modern Motif', 'Plafon modern dengan motif geometris', 680000, 6, 'plafon8.png'),
        ('Plafon Kayu Laminasi', 'Plafon kayu laminasi awet dan cantik', 800000, 4, 'plafon9.png'),
        ('Plafon PVC Motif Bunga', 'Plafon PVC dengan motif bunga', 370000, 10, 'plafon10.png')
    ");
}

$products = $koneksi->query("SELECT * FROM produk ORDER BY id DESC");
?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<title>Data Produk - PLAFON KITA</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
:root {
    --primary: #8B0000;
    --secondary: #FF6347;
    --bg: #f5f5f5;
    --card-bg: #fff;
    --text-dark: #333;
}
*{margin:0;padding:0;box-sizing:border-box;font-family:'Segoe UI',sans-serif;}
body{background:var(--bg);display:flex;min-height:100vh;}

/* Sidebar */
.sidebar{
    width:240px;background:var(--primary);color:#fff;position:fixed;height:100%;
    display:flex;flex-direction:column;align-items:center;padding-top:20px;
}
.sidebar h2{text-align:center;margin-bottom:30px;font-size:22px;letter-spacing:1px;}
.sidebar a{
    display:flex;align-items:center;width:90%;padding:12px 15px;
    color:#fff;text-decoration:none;margin-bottom:10px;border-radius:8px;
    transition:0.3s;
}
.sidebar a:hover{background:var(--secondary);}
.sidebar a i{margin-right:10px;}

/* Content */
.content{margin-left:240px;padding:25px;flex:1;}
h1{color:var(--primary);margin-bottom:15px;}
.btn{padding:6px 10px;color:white;text-decoration:none;border-radius:5px;margin-right:5px;}
.btn-add{background:#28a745;}
.btn-edit{background:#ffc107;color:#000;}
.btn-del{background:#dc3545;}

/* Table */
table{width:100%;border-collapse:collapse;margin-top:15px;background:#fff;box-shadow:0 6px 18px rgba(0,0,0,0.08);}
th, td{padding:12px;text-align:left;border-bottom:1px solid #ddd;}
th{background:var(--primary);color:#fff;}
tr:nth-child(even){background:#f9f9f9;}
tr:hover{background:#f1e6e6;transition:0.3s;}
.img-prod{width:60px;border-radius:5px;}
@media(max-width:768px){.sidebar{width:200px}.content{margin-left:200px}}
</style>
</head>
<body>

<div class="sidebar">
    <h2>PLAFON KITA</h2>
    <a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
    <a href="produk.php" style="background:var(--secondary);"><i class="fas fa-box"></i> Produk</a>
    <a href="orders.php"><i class="fas fa-receipt"></i> Pesanan</a>
    <a href="customers.php"><i class="fas fa-users"></i> Pelanggan</a>
    <a href="../auth/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
</div>

<div class="content">
<h1>Data Produk</h1>
<a class="btn btn-add" href="tambah_produk.php"><i class="fas fa-plus"></i> Tambah Produk</a>

<table>
<tr>
    <th>No</th>
    <th>Gambar</th>
    <th>Nama</th>
    <th>Harga</th>
    <th>Stok</th>
    <th>Aksi</th>
</tr>
<?php $no=1; while($p = $products->fetch_assoc()): ?>
<tr>
    <td><?= $no++ ?></td>
    <td><img src="../uploads/<?= $p['gambar'] ?>" class="img-prod"></td>
    <td><?= htmlspecialchars($p['nama']) ?></td>
    <td>Rp <?= number_format($p['harga'],0,',','.') ?></td>
    <td><?= intval($p['stok']) ?></td>
    <td>
        <a class="btn btn-edit" href="edit_produk.php?id=<?= $p['id'] ?>"><i class="fas fa-edit"></i> Edit</a>
        <a class="btn btn-del" href="hapus_produk.php?id=<?= $p['id'] ?>" onclick="return confirm('Hapus produk?')"><i class="fas fa-trash"></i> Hapus</a>
    </td>
</tr>
<?php endwhile; ?>
</table>
</div>

</body>
</html>
