<?php
require_once __DIR__ . '/../config/koneksi.php';
session_start();
if(!isset($_SESSION['user'])) header('Location: ../auth/login.php');

// Ambil semua produk untuk form
$products = [];
$res = $koneksi->query("SELECT sku, name, price, stock FROM products ORDER BY name ASC");
while($row = $res->fetch_assoc()) { $products[] = $row; }

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $customer_name = $koneksi->real_escape_string($_POST['customer_name'] ?? 'Umum');
    $order_date = date('Y-m-d H:i:s');
    $status = 'Pending';

    // Hitung total
    $total = 0;
    foreach($_POST['qty'] as $sku => $qty){
        $price = floatval($_POST['price'][$sku]);
        $total += $price * intval($qty);
    }

    // Insert customer jika nama baru
    $stmt = $koneksi->prepare("INSERT INTO customers (name) VALUES (?)");
    $stmt->bind_param("s", $customer_name);
    $stmt->execute();
    $customer_id = $stmt->insert_id;

    // Insert order
    $stmt2 = $koneksi->prepare("INSERT INTO orders (customer_id, order_date, status, total) VALUES (?, ?, ?, ?)");
    $stmt2->bind_param("issi", $customer_id, $order_date, $status, $total);
    $stmt2->execute();
    $order_id = $stmt2->insert_id;

    // Insert detail order
    $stmt3 = $koneksi->prepare("INSERT INTO order_details (order_id, sku, quantity) VALUES (?, ?, ?)");
    foreach($_POST['qty'] as $sku => $qty){
        $qty = intval($qty);
        if($qty > 0){
            $stmt3->bind_param("isi", $order_id, $sku, $qty);
            $stmt3->execute();
            // Kurangi stok produk
            $koneksi->query("UPDATE products SET stock = stock - $qty WHERE sku = '$sku'");
        }
    }

    header("Location: orders.php");
    exit;
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Tambah Pesanan</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
body { font-family: Arial, sans-serif; background:#fdf6f6; margin:0; padding:0;}
.container { max-width: 900px; margin:40px auto; background:#fff; padding:25px; border-radius:10px; box-shadow:0 6px 18px rgba(0,0,0,0.1);}
h2 { text-align:center; color:maroon; margin-bottom:25px;}
table { width:100%; border-collapse:collapse; margin-bottom:15px;}
th, td { padding:10px; text-align:left; border-bottom:1px solid #ddd;}
th { background:maroon; color:#fff;}
input[type=number] { width:60px; padding:5px; border:1px solid #ccc; border-radius:4px;}
input[type=text] { width:100%; padding:6px; border:1px solid #ccc; border-radius:4px;}
button { padding:10px 20px; background:maroon; color:#fff; border:none; border-radius:6px; cursor:pointer; transition:0.3s;}
button:hover { background:#800000;}
.total-display { font-weight:bold; font-size:18px; color:maroon;}
.back-link { display:block; text-align:center; margin-top:20px; color:maroon; font-weight:bold; text-decoration:none;}
.back-link:hover { text-decoration:underline;}
</style>
</head>
<body>
<div class="container">
<h2>Tambah Pesanan</h2>
<form method="post" id="order-form">
    <label>Nama Pelanggan:</label>
    <input type="text" name="customer_name" placeholder="Masukkan nama pelanggan" required>

    <table>
        <tr>
            <th>Produk</th>
            <th>Harga (Rp)</th>
            <th>Stok</th>
            <th>Jumlah</th>
        </tr>
        <?php foreach($products as $p): ?>
        <tr>
            <td><?= htmlspecialchars($p['name']) ?></td>
            <td><?= number_format($p['price'],0,',','.') ?></td>
            <td><?= intval($p['stock']) ?></td>
            <td>
                <input type="number" min="0" max="<?= intval($p['stock']) ?>" value="0" name="qty[<?= $p['sku'] ?>]" data-price="<?= $p['price'] ?>">
                <input type="hidden" name="price[<?= $p['sku'] ?>]" value="<?= $p['price'] ?>">
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
    <p class="total-display">Total: Rp <span id="total">0</span></p>
    <button type="submit">Simpan Pesanan</button>
</form>
<a class="back-link" href="orders.php">← Kembali ke Daftar Pesanan</a>
</div>

<script>
// Hitung total otomatis
const qtyInputs = document.querySelectorAll('input[type=number][name^="qty"]');
const totalEl = document.getElementById('total');

function updateTotal(){
    let total = 0;
    qtyInputs.forEach(input => {
        const price = parseFloat(input.dataset.price);
        const qty = parseInt(input.value) || 0;
        total += price * qty;
    });
    totalEl.textContent = total.toLocaleString('id-ID');
}

qtyInputs.forEach(input => input.addEventListener('input', updateTotal));
</script>
</body>
</html>
