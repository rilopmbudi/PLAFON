<?php
require_once __DIR__ . '/../config/koneksi.php';
session_start();
if(!isset($_SESSION['user'])) header('Location: ../auth/login.php');

$id = intval($_GET['id'] ?? 0);
if($id > 0){
    $stmt = $koneksi->prepare('DELETE FROM products WHERE id = ?');
    $stmt->bind_param('i', $id);
    $stmt->execute();
}
header('Location: produk.php');
exit;
?>
