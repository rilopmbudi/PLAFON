<?php
require_once __DIR__ . '/../config/koneksi.php';
session_start();
if(!isset($_SESSION['user'])) {
    header('Location: ../auth/login.php');
    exit;
}

// Ambil parameter
$id = intval($_GET['id'] ?? 0);
$action = strtolower(trim($_GET['action'] ?? ''));

if($id && in_array($action,['approve','reject'])){
    $status = $action=='approve' ? 'selesai' : 'batal';
    $stmt = $koneksi->prepare("UPDATE orders SET status=? WHERE id=?");
    $stmt->bind_param("si",$status,$id);
    $stmt->execute();
    $stmt->close();
}

// Kembali ke halaman orders
header('Location: orders.php');
exit;
