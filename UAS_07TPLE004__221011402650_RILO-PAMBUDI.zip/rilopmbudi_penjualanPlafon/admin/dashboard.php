<?php
require_once __DIR__ . '/../config/koneksi.php';
session_start();
if(!isset($_SESSION['user'])) {
    header('Location: ../auth/login.php');
    exit;
}

// Statistik
$totalProducts = $koneksi->query("SELECT COUNT(*) AS c FROM produk")->fetch_assoc()['c'] ?? 0;
$totalOrders = $koneksi->query("SELECT COUNT(*) AS c FROM orders")->fetch_assoc()['c'] ?? 0;
$totalPending = $koneksi->query("SELECT COUNT(*) AS c FROM orders WHERE status='pending'")->fetch_assoc()['c'] ?? 0;
$totalCustomers = $koneksi->query("SELECT COUNT(*) AS c FROM users WHERE role='customer'")->fetch_assoc()['c'] ?? 0;
?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Dashboard Admin</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<style>
:root {
    --primary: #8B0000;
    --secondary: #FF6347;
    --bg: #f5f5f5;
    --card-bg: #fff;
    --text-dark: #333;
}
*{margin:0;padding:0;box-sizing:border-box;font-family:'Segoe UI',sans-serif}
body{background:var(--bg);display:flex;min-height:100vh;}

/* Sidebar */
.sidebar{
    width:240px;background:var(--primary);color:#fff;position:fixed;height:100%;
    display:flex;flex-direction:column;align-items:center;padding-top:20px;transition:width 0.3s;
}
.sidebar h2{text-align:center;margin-bottom:30px;font-size:22px;letter-spacing:1px}
.sidebar a{
    display:flex;align-items:center;width:90%;padding:12px 15px;
    color:#fff;text-decoration:none;margin-bottom:10px;border-radius:8px;
    transition:0.3s;
}
.sidebar a:hover{background:var(--secondary);color:#fff;}
.sidebar a i{margin-right:10px;}

/* Content */
.content{margin-left:240px;padding:25px;flex:1}
.header{display:flex;justify-content:space-between;align-items:center;margin-bottom:25px;}
.header h1{color:var(--primary)}
.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:20px;margin-bottom:25px;}
.card{background:var(--card-bg);padding:20px;border-radius:12px;box-shadow:0 8px 20px rgba(0,0,0,0.08);transition:0.3s}
.card:hover{transform:translateY(-5px);}
.card h3{font-size:28px;color:var(--primary);margin-bottom:5px}
.card p{color:var(--text-dark);font-size:14px;}
.card .icon{font-size:30px;color:var(--secondary);margin-bottom:10px;transition:transform 0.3s;}
.card:hover .icon{transform:rotate(15deg);}
.welcome{margin-bottom:25px;}
.welcome h2{color:var(--primary);margin-bottom:8px;}
.welcome p{color:var(--text-dark);line-height:1.5;}
.btn-group a{
    display:inline-block;padding:10px 15px;margin-right:10px;
    border-radius:8px;text-decoration:none;color:#fff;background:var(--secondary);
    transition:0.3s;
}
.btn-group a:hover{background:var(--primary);}
.chart-container{
    background:white;padding:20px;border-radius:12px;box-shadow:0 8px 20px rgba(0,0,0,0.08);margin-bottom:25px;
}
@media(max-width:768px){.sidebar{width:200px}.content{margin-left:200px}}
@media(max-width:500px){.stats{grid-template-columns:1fr}}
</style>
</head>
<body>

<div class="sidebar">
    <h2>PLAFON KITA</h2>
    <a href="dashboard.php"><i class="fas fa-tachometer-alt"></i>Dashboard</a>
    <a href="produk.php"><i class="fas fa-box"></i>Produk</a>
    <a href="orders.php"><i class="fas fa-receipt"></i>Pesanan</a>
    <a href="customers.php"><i class="fas fa-users"></i>Pelanggan</a>
    <a href="../auth/logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
</div>

<div class="content">
    <div class="header">
        <h1>Dashboard Admin</h1>
        <span>Halo, <?= htmlspecialchars($_SESSION['user']['full_name']) ?></span>
    </div>

    <div class="stats">
        <a href="produk.php" class="card" style="text-decoration:none; color:inherit;">
            <div class="icon"><i class="fas fa-box"></i></div>
            <h3><?= $totalProducts ?></h3>
            <p>Jumlah Produk</p>
        </a>
        <a href="orders.php" class="card" style="text-decoration:none; color:inherit;">
            <div class="icon"><i class="fas fa-receipt"></i></div>
            <h3><?= $totalOrders ?></h3>
            <p>Total Pesanan</p>
        </a>
        <a href="orders.php?status=pending" class="card" style="text-decoration:none; color:inherit;">
            <div class="icon"><i class="fas fa-bell"></i></div>
            <h3><?= $totalPending ?></h3>
            <p>Pesanan Masuk</p>
        </a>
        <a href="customers.php" class="card" style="text-decoration:none; color:inherit;">
            <div class="icon"><i class="fas fa-users"></i></div>
            <h3><?= $totalCustomers ?></h3>
            <p>Pelanggan</p>
        </a>
    </div>

    <div class="welcome card">
        <h2>Selamat datang, <?= htmlspecialchars($_SESSION['user']['full_name']) ?></h2>
        <p>Ini adalah panel admin sistem informasi penjualan plafon. Kelola produk, pesanan, dan pelanggan dengan mudah melalui dashboard ini.</p>
        <div class="btn-group">
            <a href="tambah_produk.php">+ Tambah Produk</a>
            <a href="orders.php">+ Lihat Pesanan</a>
        </div>
    </div>

    <!-- Chart keren -->
    <div class="chart-container">
        <canvas id="dashboardChart" height="150"></canvas>
    </div>

</div>

<script>
const ctx = document.getElementById('dashboardChart').getContext('2d');

// Gradients
const gradient1 = ctx.createLinearGradient(0, 0, 0, 400);
gradient1.addColorStop(0, '#FF6347'); gradient1.addColorStop(1, '#FF8C00');
const gradient2 = ctx.createLinearGradient(0, 0, 0, 400);
gradient2.addColorStop(0, '#8B0000'); gradient2.addColorStop(1, '#FF4500');
const gradient3 = ctx.createLinearGradient(0, 0, 0, 400);
gradient3.addColorStop(0, '#20B2AA'); gradient3.addColorStop(1, '#3CB371');
const gradient4 = ctx.createLinearGradient(0, 0, 0, 400);
gradient4.addColorStop(0, '#1E90FF'); gradient4.addColorStop(1, '#00BFFF');

new Chart(ctx, {
    type: 'bar',
    data: {
        labels: ['Produk', 'Pesanan', 'Pesanan Masuk', 'Pelanggan'],
        datasets: [{
            label: 'Jumlah',
            data: [<?= $totalProducts ?>, <?= $totalOrders ?>, <?= $totalPending ?>, <?= $totalCustomers ?>],
            backgroundColor: [gradient2, gradient1, gradient3, gradient4],
            borderRadius: 12,
            borderSkipped: false
        }]
    },
    options: {
        responsive:true,
        plugins: {
            legend: { display:false },
            tooltip: {
                backgroundColor: '#333',
                titleColor: '#fff',
                bodyColor: '#fff',
                padding:10,
                cornerRadius:8
            }
        },
        scales: {
            y: { beginAtZero:true, ticks: { stepSize: 1 } },
            x: { grid: { display:false } }
        },
        animation: { duration: 1200, easing: 'easeOutQuart' }
    }
});
</script>

</body>
</html>
