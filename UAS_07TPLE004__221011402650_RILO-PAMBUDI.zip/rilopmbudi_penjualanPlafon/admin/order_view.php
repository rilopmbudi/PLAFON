<?php
require_once __DIR__ . '/../config/koneksi.php';
session_start();

// Cek login
if(!isset($_SESSION['user'])) {
    header('Location: ../auth/login.php');
    exit;
}

// Ambil ID pesanan
$id = intval($_GET['id'] ?? 0);

// Ambil data pesanan beserta nama customer
$orderQuery = $koneksi->query("
    SELECT o.*, u.username AS customer_name
    FROM orders o
    LEFT JOIN users u ON o.user_id = u.id
    WHERE o.id = $id
");
if(!$orderQuery) die("Query pesanan gagal: ".$koneksi->error);
$order = $orderQuery->fetch_assoc();
if(!$order) die("Pesanan tidak ditemukan!");

// Handle approve/reject
if(isset($_POST['action'])) {
    $newStatus = $_POST['action'] === 'approve' ? 'proses' : 'batal';
    $update = $koneksi->query("UPDATE orders SET status='$newStatus' WHERE id=$id");
    if(!$update) die("Update status gagal: ".$koneksi->error);
    header("Location: order_view.php?id=$id");
    exit;
}

// Ambil detail produk dari order_items
$items = $koneksi->query("
    SELECT oi.*, p.nama AS product_name
    FROM order_items oi
    LEFT JOIN produk p ON oi.produk_id = p.id
    WHERE oi.order_id = $id
");
if(!$items) die("Query detail produk gagal: ".$koneksi->error);
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Detail Pesanan #<?= $order['id'] ?> - PLAFON KITA</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
body{font-family:'Segoe UI',sans-serif;background:#f5f5f5;margin:0;padding:20px;}
.container{max-width:900px;margin:auto;}
.card{background:#fff;padding:20px;border-radius:10px;box-shadow:0 5px 15px rgba(0,0,0,0.1);margin-bottom:20px;}
h2{color:#8B0000;margin-bottom:15px;}
table{width:100%;border-collapse:collapse;margin-top:10px;}
th, td{padding:10px;text-align:left;border-bottom:1px solid #ddd;}
th{background:#8B0000;color:#fff;}
tr:nth-child(even){background:#f9f9f9;}
tr:hover{background:#f1e6e6;transition:0.3s;}
.status{padding:5px 10px;border-radius:5px;color:#fff;font-weight:bold;}
.status-pending{background:#ffc107;}
.status-proses{background:#28a745;}
.status-selesai{background:#007bff;}
.status-batal{background:#dc3545;}
.btn{display:inline-block;padding:8px 15px;margin-right:10px;border:none;border-radius:5px;color:#fff;font-weight:bold;cursor:pointer;transition:0.3s;}
.btn-approve{background:#28a745;}
.btn-approve:hover{background:#218838;}
.btn-reject{background:#dc3545;}
.btn-reject:hover{background:#c82333;}
.back-link{display:inline-block;margin-top:10px;color:#8B0000;text-decoration:none;font-weight:bold;}
.back-link:hover{color:#FF6347;}
@media screen and (max-width:768px){table, th, td{font-size:14px;padding:8px;}}
</style>
</head>
<body>

<div class="container">
    <div class="card">
        <h2>Detail Pesanan #<?= $order['id'] ?></h2>
        <p><strong>Pelanggan:</strong> <?= htmlspecialchars($order['customer_name'] ?? 'Umum') ?></p>
        <p><strong>Tanggal:</strong> <?= $order['tanggal'] ?></p>
        <p><strong>Status:</strong> 
            <span class="status status-<?= strtolower($order['status']) ?>"><?= htmlspecialchars($order['status']) ?></span>
        </p>
        <p><strong>Total:</strong> Rp <?= number_format($order['total'],0,',','.') ?></p>

        <?php if($order['status'] === 'pending'): ?>
        <form method="post" style="margin-top:15px;">
            <button type="submit" name="action" value="approve" class="btn btn-approve"><i class="fas fa-check"></i> Approve</button>
            <button type="submit" name="action" value="reject" class="btn btn-reject"><i class="fas fa-times"></i> Reject</button>
        </form>
        <?php endif; ?>
    </div>

    <div class="card">
        <h2>Produk yang dipesan</h2>
        <table>
            <tr>
                <th>No</th>
                <th>Produk</th>
                <th>Harga</th>
                <th>Qty</th>
                <th>Subtotal</th>
            </tr>
            <?php $no=1; while($item = $items->fetch_assoc()): ?>
            <tr>
                <td><?= $no++ ?></td>
                <td><?= htmlspecialchars($item['product_name']) ?></td>
                <td>Rp <?= number_format($item['harga'],0,',','.') ?></td>
                <td><?= $item['qty'] ?></td>
                <td>Rp <?= number_format($item['qty'] * $item['harga'],0,',','.') ?></td>
            </tr>
            <?php endwhile; ?>
        </table>
    </div>

    <a class="back-link" href="orders.php">← Kembali ke Daftar Pesanan</a>
</div>

</body>
</html>
