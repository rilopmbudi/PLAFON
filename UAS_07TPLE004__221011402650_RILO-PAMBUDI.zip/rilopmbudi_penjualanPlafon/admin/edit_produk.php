<?php
session_start();
require_once __DIR__ . '/../config/koneksi.php';

// Cek login admin
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: ../auth/login.php");
    exit;
}

// Pastikan ada ID produk
if (!isset($_GET['id'])) {
    die("Produk tidak ditemukan.");
}

$id = intval($_GET['id']);

// Ambil data produk
$stmt = $koneksi->prepare("SELECT * FROM produk WHERE id=? LIMIT 1");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) die("Produk tidak ditemukan.");
$p = $result->fetch_assoc();

// ==========================
// PROSES UPDATE PRODUK
// ==========================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $nama  = $_POST['nama'];
    $harga = floatval($_POST['harga']);
    $stok  = intval($_POST['stok']);

    $fotoBaru = $p['gambar'];

    // Upload foto baru
    if (!empty($_FILES['gambar']['name'])) {
        $ext = pathinfo($_FILES['gambar']['name'], PATHINFO_EXTENSION);
        $fileName = "produk_" . time() . "_" . rand(100,999) . "." . $ext;

        $uploadPath = "../uploads/" . $fileName;
        move_uploaded_file($_FILES['gambar']['tmp_name'], $uploadPath);

        // Hapus foto lama
        if ($p['gambar'] && file_exists("../uploads/" . $p['gambar'])) {
            unlink("../uploads/" . $p['gambar']);
        }

        $fotoBaru = $fileName;
    }

    // Update database
    $update = $koneksi->prepare("
        UPDATE produk SET nama=?, harga=?, stok=?, gambar=? WHERE id=?");
    $update->bind_param("sdisi", $nama, $harga, $stok, $fotoBaru, $id);
    $update->execute();

    header("Location: produk.php");
    exit;
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Edit Produk</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
body{
    font-family:'Segoe UI';
    background:#f4f4f4;
    margin:0;
    padding:0;
}

.container{
    width:700px;
    margin:40px auto;
    background:white;
    padding:30px;
    border-radius:14px;
    box-shadow:0 4px 14px rgba(0,0,0,0.15);
}

h2{
    text-align:center;
    color:#8B0000;
    margin-bottom:20px;
}

/* FLEX CONTAINER DUA KOLOM */
.form-row{
    display:flex;
    gap:20px;
    align-items:flex-start;
}

.form-left{
    flex:1;
}

.form-right{
    width:220px;
    text-align:center;
}

label{
    font-weight:600;
    font-size:14px;
    margin-bottom:6px;
    display:block;
}

input{
    width:100%;
    padding:11px;
    margin-bottom:12px;
    border-radius:8px;
    border:1px solid #ccc;
    font-size:15px;
    background:#fafafa;
}

button{
    width:100%;
    padding:12px;
    background:#8B0000;
    color:white;
    border:none;
    border-radius:8px;
    font-size:16px;
    cursor:pointer;
    margin-top:10px;
}
button:hover{
    background:#A30000;
}

.preview-box{
    text-align:center;
    margin-top:12px;
}

.preview-box img{
    width:100%;
    border-radius:12px;
    box-shadow:0 2px 8px rgba(0,0,0,0.15);
}

.back-btn {
    display:inline-block;
    padding:8px 14px;
    font-size:13px;
    background:#555;
    color:white;
    border-radius:8px;
    text-decoration:none;
    margin-bottom:12px;
    transition:0.2s;
}
.back-btn:hover {
    background:#333;
}
</style>
</head>

<body>

<div class="container">

    <a href="produk.php" class="back-btn">
        <i class="fa fa-arrow-left"></i> Kembali
    </a>

    <h2>Edit Produk</h2>

    <div class="form-row">
        <!-- KOLOM KIRI -->
        <div class="form-left">
            <form method="POST" enctype="multipart/form-data">

                <label>Nama Produk</label>
                <input type="text" name="nama" value="<?= htmlspecialchars($p['nama']) ?>" required>

                <label>Harga</label>
                <input type="number" name="harga" value="<?= $p['harga'] ?>" required>

                <label>Stok</label>
                <input type="number" name="stok" value="<?= $p['stok'] ?>" required>

                <label>Ganti Foto (opsional)</label>
                <input type="file" name="gambar" accept="image/*">

                <button type="submit">
                    <i class="fa fa-save"></i> Simpan Perubahan
                </button>
            </form>
        </div>

        <!-- KOLOM KANAN -->
        <div class="form-right">
            <label>Foto Saat Ini</label>
            <div class="preview-box">
                <img src="../uploads/<?= $p['gambar'] ?>" alt="gambar produk">
            </div>
        </div>
    </div>

</div>

</body>
</html>
