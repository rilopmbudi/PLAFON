<?php
require_once __DIR__ . '/../config/koneksi.php';
session_start();
if(!isset($_SESSION['user'])) header('Location: ../auth/login.php');

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $code = $koneksi->real_escape_string($_POST['code']);
    $name = $koneksi->real_escape_string($_POST['name']);
    $phone = $koneksi->real_escape_string($_POST['phone']);
    $address = $koneksi->real_escape_string($_POST['address']);

    $stmt = $koneksi->prepare("INSERT INTO customers (code, name, phone, address) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $code, $name, $phone, $address);
    $stmt->execute();

    header("Location: customer.php");
    exit;
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Tambah Customer</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
body{font-family:Arial;background:#fdf6f6;margin:0;padding:0;}
.container{max-width:400px;margin:40px auto;background:#fff;padding:25px;border-radius:10px;box-shadow:0 6px 18px rgba(0,0,0,0.1);}
h2{text-align:center;color:maroon;margin-bottom:20px;}
form label{font-weight:bold;margin-bottom:5px;display:block;color:#333;}
form input{width:100%;padding:10px;margin-bottom:12px;border:1px solid #ccc;border-radius:6px;font-size:14px;box-sizing:border-box;}
form input:focus{border-color:maroon;outline:none;box-shadow:0 0 5px rgba(128,0,0,0.3);}
button{width:100%;padding:12px;background:maroon;color:#fff;border:none;border-radius:6px;font-size:16px;cursor:pointer;transition:background 0.3s;}
button:hover{background:#800000;}
.back-link{display:block;text-align:center;margin-top:15px;color:maroon;text-decoration:none;font-weight:bold;}
.back-link:hover{text-decoration:underline;}
</style>
</head>
<body>
<div class="container">
<h2>Tambah Customer</h2>
<form method="post">
    <label>Kode Customer</label>
    <input name="code" placeholder="Contoh: CUST-006" required>

    <label>Nama</label>
    <input name="name" placeholder="Nama lengkap" required>

    <label>Telepon</label>
    <input name="phone" placeholder="081234567890" required>

    <label>Alamat</label>
    <input name="address" placeholder="Alamat lengkap" required>

    <button type="submit">Simpan</button>
</form>
<a class="back-link" href="customer.php">← Kembali ke Data Customer</a>
</div>
</body>
</html>
