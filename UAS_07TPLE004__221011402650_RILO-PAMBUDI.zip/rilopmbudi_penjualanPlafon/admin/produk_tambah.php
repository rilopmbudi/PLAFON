<?php
require_once __DIR__ . '/../config/koneksi.php';
session_start();
if(!isset($_SESSION['user'])) header('Location: ../auth/login.php');

// Tambahkan produk dummy jika database kosong
$resCount = $koneksi->query("SELECT COUNT(*) AS total FROM products")->fetch_assoc()['total'];
if($resCount == 0){
    $dummyProducts = [
        ['PLF-PVC-001','Plafon PVC Standard','PVC',15000,50],
        ['PLF-PVC-002','Plafon PVC Motif','PVC',18000,30],
        ['PLF-GYS-001','Plafon Gypsum Standard','Gypsum',20000,40],
        ['PLF-GYS-002','Plafon Gypsum Premium','Gypsum',35000,20],
        ['PLF-WOD-001','Plafon Kayu Natural','Kayu',40000,15],
        ['PLF-MET-001','Plafon Metal Minimalis','Metal',45000,10],
        ['PLF-GYS-003','Plafon Gypsum 3D','Gypsum',50000,25],
        ['PLF-PVC-003','Plafon PVC Anti Air','PVC',22000,35],
        ['PLF-WOD-002','Plafon Kayu Dark','Kayu',42000,12],
        ['PLF-MET-002','Plafon Metal Motif','Metal',48000,8],
    ];

    $stmt = $koneksi->prepare("INSERT INTO products (sku, name, category, price, stock) VALUES (?, ?, ?, ?, ?)");
    foreach($dummyProducts as $p){
        [$sku,$name,$cat,$price,$stock] = $p;
        $stmt->bind_param("sssdi", $sku,$name,$cat,$price,$stock);
        $stmt->execute();
    }
}

// Ambil data produk untuk datalist
$products = [];
$res = $koneksi->query("SELECT sku, name, category, price FROM products ORDER BY name ASC");
while($row = $res->fetch_assoc()) {
    $products[] = $row;
}

$success = $error = "";

// Proses tambah produk
if($_SERVER['REQUEST_METHOD'] === 'POST'){

    $sku = $koneksi->real_escape_string($_POST['sku']);
    $name = $koneksi->real_escape_string($_POST['name']);
    $category = $koneksi->real_escape_string($_POST['category']);
    $price = floatval($_POST['price']);
    $stock = intval($_POST['stock']);
    $photo = null;

    // ----------- UPLOAD FOTO --------------
    if (!empty($_FILES['photo']['name'])) {

        $allowed = ['jpg','jpeg','png','webp'];
        $fname   = $_FILES['photo']['name'];
        $tmp     = $_FILES['photo']['tmp_name'];
        $ext     = strtolower(pathinfo($fname, PATHINFO_EXTENSION));

        if (!in_array($ext, $allowed)) {
            $error = "Format foto harus JPG, PNG, atau WEBP.";
        } else {
            $newFile = "produk_" . time() . "_" . rand(100,999) . "." . $ext;
            $path = __DIR__ . '/../uploads/' . $newFile;

            if (move_uploaded_file($tmp, $path)) {
                $photo = $newFile;
            } else {
                $error = "Gagal meng-upload foto.";
            }
        }
    }

    if (!$error) {
        $stmt = $koneksi->prepare("INSERT INTO products (sku, name, category, price, stock, photo) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssdis", $sku, $name, $category, $price, $stock, $photo);
        $stmt->execute();
        $success = "Produk berhasil ditambahkan!";
    }
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Tambah Produk - PLAFON KITA</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
:root {
    --primary: #8B0000;
    --secondary: #FF6347;
    --bg: #f5f5f5;
    --card-bg: #fff;
    --text-dark: #333;
}

* {margin:0; padding:0; box-sizing:border-box; font-family:'Segoe UI', sans-serif;}
body{background:var(--bg); display:flex; min-height:100vh;}

.sidebar{
    width:240px; background:var(--primary); color:#fff; position:fixed; height:100%;
    display:flex; flex-direction:column; align-items:center; padding-top:20px;
}
.sidebar a{
    width:90%; padding:12px 15px; color:#fff; text-decoration:none; margin-bottom:10px; border-radius:8px;
}
.content{margin-left:240px; padding:25px;}
h1{text-align:center; color:var(--primary);}

.form-card{
    background:#fff; padding:25px; border-radius:12px; max-width:450px; margin:0 auto;
}

input,select{
    width:100%; padding:12px; margin-bottom:12px; border-radius:8px; border:1px solid #ccc;
}
button{
    width:100%; padding:12px; background:var(--primary); color:#fff; border:none; border-radius:8px;
}

.success{padding:10px; background:#d4edda; color:#155724; margin-bottom:10px; border-radius:6px;}
.error{padding:10px; background:#f8d7da; color:#721c24; margin-bottom:10px; border-radius:6px;}

</style>
</head>
<body>

<div class="sidebar">
    <h2>PLAFON KITA</h2>
    <a href="dashboard.php"><i class="fa fa-home"></i> Dashboard</a>
    <a href="produk.php"><i class="fa fa-box"></i> Data Produk</a>
    <a href="orders.php"><i class="fa fa-receipt"></i> Pesanan</a>
    <a href="../auth/logout.php"><i class="fa fa-sign-out-alt"></i> Logout</a>
</div>

<div class="content">
    <h1>Tambah Produk</h1>

    <div class="form-card">

        <?php if($success): ?>
            <div class="success"><?= $success ?></div>
        <?php endif; ?>

        <?php if($error): ?>
            <div class="error"><?= $error ?></div>
        <?php endif; ?>

        <form method="post" enctype="multipart/form-data">

            <label>SKU</label>
            <input name="sku" list="sku-list" required>
            <datalist id="sku-list">
                <?php foreach($products as $p): ?>
                    <option value="<?= htmlspecialchars($p['sku']) ?>"><?= htmlspecialchars($p['name']) ?></option>
                <?php endforeach; ?>
            </datalist>

            <label>Nama Produk</label>
            <input name="name" list="name-list" required>
            <datalist id="name-list">
                <?php foreach($products as $p): ?>
                    <option value="<?= htmlspecialchars($p['name']) ?>"></option>
                <?php endforeach; ?>
            </datalist>

            <label>Kategori</label>
            <input name="category" list="cat-list">
            <datalist id="cat-list">
                <?php
                $cats = [];
                foreach($products as $p) { $cats[$p['category']] = true; }
                foreach(array_keys($cats) as $c): ?>
                    <option value="<?= htmlspecialchars($c) ?>"></option>
                <?php endforeach; ?>
            </datalist>

            <label>Harga</label>
            <input type="number" name="price" required>

            <label>Stok</label>
            <input type="number" name="stock" required>

            <label>Foto Produk</label>
            <input type="file" name="photo" accept="image/*">

            <button type="submit">Tambah Produk</button>
        </form>

    </div>
</div>

</body>
</html>
