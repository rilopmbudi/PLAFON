<?php
session_start();
require_once __DIR__ . '/../config/koneksi.php';

// Jika belum login
if (!isset($_SESSION['user'])) {
    header("Location: ../auth/login.php");
    exit;
}

// Hanya customer yang boleh
if ($_SESSION['user']['role'] !== 'customer') {
    header("Location: ../auth/login.php");
    exit;
}

$user_id = $_SESSION['user']['id'];

// Pastikan ada ID keranjang yang dikirim
if (!isset($_GET['id'])) {
    header("Location: keranjang.php");
    exit;
}

$keranjang_id = intval($_GET['id']);

// Cek apakah item ini benar-benar milik user
$stmt = $koneksi->prepare("SELECT id FROM keranjang WHERE id = ? AND user_id = ?");
$stmt->bind_param("ii", $keranjang_id, $user_id);
$stmt->execute();
$cek = $stmt->get_result()->fetch_assoc();

if (!$cek) {
    // Jika bukan milik user, redirect
    header("Location: keranjang.php?error=unauthorized");
    exit;
}

// Hapus produk dari keranjang
$stmt = $koneksi->prepare("DELETE FROM keranjang WHERE id = ? AND user_id = ?");
$stmt->bind_param("ii", $keranjang_id, $user_id);

if ($stmt->execute()) {
    header("Location: keranjang.php?success=deleted");
    exit;
} else {
    header("Location: keranjang.php?error=failed");
    exit;
}
