<?php
session_start();
require_once __DIR__ . '/../config/koneksi.php';

if (!isset($_SESSION['user'])) {
    header("Location: ../auth/login.php");
    exit;
}

// Cek role customer
if ($_SESSION['user']['role'] !== 'customer') {
    header("Location: ../auth/login.php");
    exit;
}

$user = $_SESSION['user'];
$user_id = $user['id'];

// QUERY AMBIL DATA KERANJANG + GAMBAR PRODUK
$q = $koneksi->prepare("
    SELECT 
        k.id AS keranjang_id,
        k.qty,
        p.nama,
        p.harga,
        p.gambar
    FROM keranjang k
    JOIN produk p ON k.produk_id = p.id
    WHERE k.user_id = ?
");
$q->bind_param("i", $user_id);
$q->execute();
$result = $q->get_result();

?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Keranjang Customer</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
body{
    margin:0;
    background:#f1f1f1;
    font-family: "Segoe UI", sans-serif;
}
.sidebar{
    width:230px;
    height:100vh;
    background:#8B0000;
    padding:20px;
    position:fixed;
    top:0; left:0;
    color:#fff;
}
.sidebar h2{
    margin:0 0 20px;
    text-align:center;
}
.sidebar a{
    display:block;
    padding:12px;
    margin-bottom:10px;
    color:white;
    text-decoration:none;
    border-radius:8px;
    transition:0.3s;
}
.sidebar a:hover{
    background:#A30000;
}

.content{
    margin-left:250px;
    padding:30px;
}

/* BOX CONTAINER */
.box{
    background:white;
    padding:25px;
    border-radius:14px;
    box-shadow:0 4px 10px rgba(0,0,0,0.1);
}

/* BACK BUTTON */
.back-btn{
    display:inline-block;
    margin-bottom:20px;
    background:#8B0000;
    padding:8px 14px;
    border-radius:8px;
    color:white;
    text-decoration:none;
}
.back-btn:hover{ background:#A30000; }

/* TITLE */
.header-title{
    display:flex;
    align-items:center;
    gap:10px;
    margin-bottom:20px;
}
.header-title h2{
    margin:0;
    color:#8B0000;
}

/* TABLE */
table{
    width:100%;
    border-collapse:collapse;
    margin-top:10px;
}
th,td{
    padding:12px;
    border:1px solid #ddd;
}
th{
    background:#8B0000;
    color:white;
}

/* PRODUCT IMAGE */
.product-img {
    width:60px;
    border-radius:6px;
}

/* FIX QTY COLUMN */
.qty-box {
    display:flex;
    align-items:center;
    justify-content:center;
    gap:6px;
    width:120px;         /* stabil */
    min-width:120px;
}

.qty-number {
    width:32px;
    text-align:center;
    font-weight:bold;
}

.btn-qty {
    padding:6px 10px;
    font-size:14px;
    border-radius:8px;
    color:white;
    text-decoration:none;
}

.btn-minus { background:#f39c12; }
.btn-plus  { background:#27ae60; }

.btn-minus:hover { background:#d78b0f; }
.btn-plus:hover  { background:#1e8f52; }

/* BUTTON DELETE */
.btn-danger{
    background:#c0392b;
    padding:7px 12px;
    text-decoration:none;
    color:white;
    border-radius:8px;
}
.btn-danger:hover{ background:#992d22; }

/* TOTAL */
.total-box{
    margin-top:20px;
    padding:15px;
    background:#eee;
    border-radius:10px;
    font-size:18px;
    font-weight:bold;
}

.footer-btn{
    margin-top:20px;
    display:flex;
    justify-content:space-between;
}

.btn{
    display:inline-block;
    padding:10px 14px;
    border-radius:8px;
    background:#8B0000;
    color:white;
    text-decoration:none;
}
.btn:hover{ background:#A30000; }

</style>
</head>
<body>

<div class="sidebar">
    <h2>PLAFON KITA</h2>
    <p>Halo, <b><?= htmlspecialchars($user['full_name']) ?></b></p>

    <a href="../customer/dashboard.php"><i class="fa-solid fa-house"></i> Dashboard</a>
    <a href="produk.php"><i class="fa-solid fa-box"></i> Produk</a>
    <a href="keranjang.php" style="background:#660000;"><i class="fa-solid fa-cart-shopping"></i> Keranjang</a>
    <a href="../orders/riwayat.php"><i class="fa-solid fa-receipt"></i> Pesanan Saya</a>
    <a href="../orders/riwayat.php"><i class="fa-solid fa-clock-rotate-left"></i> Riwayat Pesanan</a>
    <a href="../auth/logout.php"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
</div>

<!-- CONTENT -->
<div class="content">
<div class="box">

    <a href="produk.php" class="back-btn"><i class="fa-solid fa-arrow-left"></i> Kembali</a>

    <div class="header-title">
        <i class="fa-solid fa-cart-shopping"></i>
        <h2>Keranjang Belanja</h2>
    </div>

    <table>
        <tr>
            <th>Produk</th>
            <th style="width:150px;">Qty</th>
            <th>Subtotal</th>
            <th>Aksi</th>
        </tr>

        <?php
        $total = 0;

        if ($result->num_rows == 0) {
            echo "<tr><td colspan='4' style='text-align:center;'>Keranjang masih kosong</td></tr>";
        } else {
            while ($i = $result->fetch_assoc()):
                $sub = $i['qty'] * $i['harga'];
                $total += $sub;
        ?>
        <tr>
            <td>
                <img class="product-img" src="../uploads/<?= $i['gambar'] ?>" alt="">
                <br>
                <?= htmlspecialchars($i['nama']) ?>
            </td>

            <td>
                <div class="qty-box">
                    <a href="update.php?id=<?= $i['keranjang_id'] ?>&aksi=minus" class="btn-qty btn-minus">-</a>
                    <span class="qty-number"><?= $i['qty'] ?></span>
                    <a href="update.php?id=<?= $i['keranjang_id'] ?>&aksi=plus" class="btn-qty btn-plus">+</a>
                </div>
            </td>

            <td>Rp <?= number_format($sub, 0, ',', '.') ?></td>

            <td>
                <a href="delete.php?id=<?= $i['keranjang_id'] ?>" 
                   class="btn-danger"
                   onclick="return confirm('Hapus item ini?')">
                   Hapus
                </a>
            </td>
        </tr>
        <?php endwhile; } ?>
    </table>

    <div class="total-box">
        Total Belanja: Rp <?= number_format($total, 0, ',', '.') ?>
    </div>

    <?php if ($total > 0): ?>
    <div class="footer-btn">
        <a href="checkout.php" class="btn"><i class="fa-solid fa-check"></i> Checkout</a>
        <a href="clear.php" class="btn-danger"
           onclick="return confirm('Hapus semua isi keranjang?')"><i class="fa-solid fa-trash"></i> Hapus Semua</a>
    </div>
    <?php endif; ?>

</div>
</div>

</body>
</html>
