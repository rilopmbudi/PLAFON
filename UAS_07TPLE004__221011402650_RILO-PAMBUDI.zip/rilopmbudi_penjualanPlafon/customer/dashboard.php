<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: ../auth/login.php");
    exit;
}

// Cek role customer
if ($_SESSION['user']['role'] !== 'customer') {
    header("Location: ../auth/login.php");
    exit;
}

$user = $_SESSION['user'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Dashboard Customer</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
body{
    margin:0;
    background:#f6f6f6;
    font-family: "Segoe UI", sans-serif;
}
.sidebar{
    width:230px;
    height:100vh;
    background:#8B0000;
    padding:20px;
    position:fixed;
    top:0; left:0;
    color:#fff;
}
.sidebar h2{
    margin:0 0 20px;
    text-align:center;
}
.sidebar a{
    display:block;
    padding:12px;
    margin-bottom:10px;
    color:white;
    text-decoration:none;
    border-radius:8px;
    transition:0.3s;
}
.sidebar a:hover{
    background:#A30000;
}
.content{
    margin-left:250px;
    padding:30px;
}
.card{
    background:white;
    padding:20px;
    border-radius:12px;
    box-shadow:0 4px 10px rgba(0,0,0,0.1);
    margin-bottom:20px;
}
</style>
</head>
<body>

<div class="sidebar">
    <h2>PLAFON KITA</h2>
    <p>Halo, <b><?= htmlspecialchars($user['full_name']) ?></b></p>

    <a href="../customer/dashboard.php"><i class="fa-solid fa-house"></i> Dashboard</a>
    <a href="produk.php"><i class="fa-solid fa-box"></i> Produk</a>
    <a href="../customer/keranjang.php"><i class="fa-solid fa-cart-shopping"></i> Keranjang</a>
    <a href="../orders/riwayat.php"><i class="fa-solid fa-receipt"></i> Pesanan Saya</a>
    <a href="../orders/riwayat.php"><i class="fa-solid fa-clock-rotate-left"></i> Riwayat Pesanan</a>
    <a href="../auth/logout.php" style="background:#660000;"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
</div>

<div class="content">
    <h1>Dashboard Customer</h1>
    <div class="card">
        <h3>Selamat datang, <?= htmlspecialchars($user['full_name']) ?> 👋</h3>
        <p>Ini adalah dashboard khusus customer. Kamu bisa melihat produk, menambah ke keranjang, dan melakukan pemesanan.</p>
    </div>
</div>

</body>
</html>
