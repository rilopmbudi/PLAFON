<?php
require_once "../config/koneksi.php";
session_start();

echo "<h3>DEBUG MODE</h3>";

// Cek login
if (!isset($_SESSION['user'])) {
    die("ERROR: Tidak login");
}

if ($_SESSION['user']['role'] !== 'customer') {
    die("ERROR: Bukan customer");
}

$user_id = $_SESSION['user']['id'];
echo "User ID: $user_id <br>";

// Cek produk id
if (!isset($_GET['id'])) {
    die("ERROR: ID produk tidak ada");
}

$produk_id = intval($_GET['id']);
echo "Produk ID: $produk_id <br>";

// Cek apakah produk ada
$produk = $koneksi->query("SELECT id FROM produk WHERE id = $produk_id");

if (!$produk) {
    die("SQL ERROR PRODUK: " . $koneksi->error);
}

if ($produk->num_rows == 0) {
    die("ERROR: Produk tidak ditemukan!");
}

echo "Produk valid<br>";

// Cek apakah sudah ada di keranjang
$cek = $koneksi->query("
    SELECT id FROM keranjang
    WHERE user_id = $user_id AND produk_id = $produk_id
");

if (!$cek) {
    die("SQL ERROR CEK: " . $koneksi->error);
}

if ($cek->num_rows > 0) {
    echo "Produk sudah ada, update qty<br>";

    $sql = "
        UPDATE keranjang SET qty = qty + 1
        WHERE user_id = $user_id AND produk_id = $produk_id
    ";

    if (!$koneksi->query($sql)) {
        die("SQL ERROR UPDATE: " . $koneksi->error);
    }

    echo "UPDATE sukses!";
} else {
    echo "Produk baru, insert keranjang<br>";

    $sql = "
        INSERT INTO keranjang (user_id, produk_id, qty)
        VALUES ($user_id, $produk_id, 1)
    ";

    if (!$koneksi->query($sql)) {
        die("SQL ERROR INSERT: " . $koneksi->error);
    }

    echo "INSERT sukses!";
}

echo "<br><br>SELESAI. <a href='keranjang.php'>Lihat keranjang</a>";
