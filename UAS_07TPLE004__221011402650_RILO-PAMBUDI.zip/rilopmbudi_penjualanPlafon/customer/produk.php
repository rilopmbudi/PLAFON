<?php
session_start();
require_once __DIR__ . '/../config/koneksi.php';

// Cek login
if (!isset($_SESSION['user'])) {
    header("Location: ../auth/login.php");
    exit;
}

// Cek role customer
if ($_SESSION['user']['role'] !== 'customer') {
    header("Location: ../auth/login.php");
    exit;
}

$user = $_SESSION['user'];
$user_id = $user['id'];

// HITUNG JUMLAH ITEM DALAM KERANJANG
$cekKeranjang = $koneksi->query("SELECT SUM(qty) AS total FROM keranjang WHERE user_id = $user_id");
$cart = $cekKeranjang->fetch_assoc();
$cartCount = $cart['total'] ?? 0;

// Ambil data produk
$query = $koneksi->query("SELECT * FROM produk ORDER BY id DESC");
$produk = $query->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Produk - Customer</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
body{
    margin:0;
    background:#f4f4f4;
    font-family: "Segoe UI", sans-serif;
}
.sidebar{
    width:230px;
    height:100vh;
    background:#8B0000;
    padding:20px;
    position:fixed;
    top:0; left:0;
    color:#fff;
}
.sidebar h2{
    margin:0 0 20px;
    text-align:center;
}
.sidebar a{
    display:block;
    padding:12px;
    margin-bottom:10px;
    color:white;
    text-decoration:none;
    border-radius:8px;
    transition:0.3s;
}
.sidebar a:hover{
    background:#A30000;
}
.content{
    margin-left:260px;
    padding:30px;
}
.product-grid{
    display:grid;
    grid-template-columns:repeat(auto-fill,minmax(250px,1fr));
    gap:20px;
}
.card{
    background:white;
    padding:15px;
    border-radius:12px;
    box-shadow:0 4px 10px rgba(0,0,0,0.1);
}
.card img{
    width:100%;
    height:180px;
    object-fit:cover;
    border-radius:8px;
}
.card h3{
    margin:10px 0 6px;
    font-size:18px;
}
.card p{ margin:6px 0; color:#333; }
.btn{
    display:inline-block;
    padding:10px;
    background:#8B0000;
    color:white;
    text-decoration:none;
    border-radius:8px;
    margin-top:10px;
    text-align:center;
    transition:0.3s;
}
.btn:hover{
    background:#A30000;
}
.no-image{
    display:flex;
    align-items:center;
    justify-content:center;
    width:100%;
    height:180px;
    background:#efefef;
    color:#999;
    border-radius:8px;
}
.qty-select{
    width:100%;
    padding:8px;
    border-radius:6px;
    border:1px solid #ccc;
    margin-top:8px;
}
</style>
</head>
<body>

<div class="sidebar">
    <h2>PLAFON KITA</h2>
    <p>Halo, <b><?= htmlspecialchars($user['full_name']) ?></b></p>

    <a href="../customer/dashboard.php"><i class="fa-solid fa-house"></i> Dashboard</a>
    <a href="produk.php"><i class="fa-solid fa-box"></i> Produk</a>
    <a href="../customer/keranjang.php"><i class="fa-solid fa-cart-shopping"></i> Keranjang</a>
    <a href="../orders/riwayat.php"><i class="fa-solid fa-receipt"></i> Pesanan Saya</a>
    <a href="../orders/riwayat.php"><i class="fa-solid fa-clock-rotate-left"></i> Riwayat Pesanan</a>
    <a href="../auth/logout.php" style="background:#660000;"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
</div>

<div class="content">
    <h1>Daftar Produk</h1>

    <div class="product-grid">
    <?php foreach ($produk as $p): 
        $name = htmlspecialchars($p['nama'] ?? $p['nama_produk'] ?? 'Nama tidak tersedia');
        $price = isset($p['harga']) ? number_format($p['harga'], 0, ',', '.') : '-';
        $stok  = isset($p['stok']) ? intval($p['stok']) : 0;
        $imgFile = $p['foto'] ?? $p['gambar'] ?? '';
        $imgPath = $imgFile ? "../uploads/" . $imgFile : '';
    ?>
        <div class="card">

            <?php if ($imgPath && file_exists(__DIR__ . '/../uploads/' . $imgFile)): ?>
                <img src="<?= $imgPath ?>" alt="<?= $name ?>">
            <?php else: ?>
                <div class="no-image">No Image</div>
            <?php endif; ?>

            <h3><?= $name ?></h3>
            <p>Harga: <b>Rp<?= $price ?></b></p>
            <p>Stok: <?= $stok ?></p>

            <!-- FORM TAMBAH KE KERANJANG -->
            <form action="../keranjang/tambah.php" method="POST">
                <input type="hidden" name="produk_id" value="<?= $p['id'] ?>">

                <select name="jumlah" class="qty-select" required>
                    <option value="">Pilih Jumlah</option>
                    <?php for ($i = 1; $i <= 10; $i++): ?>
                        <option value="<?= $i ?>"><?= $i ?></option>
                    <?php endfor; ?>
                </select>

                <button type="submit" class="btn" style="width:100%; margin-top:10px;">
                    <i class="fa-solid fa-cart-plus"></i> Tambah ke Keranjang
                </button>
            </form>

        </div>
    <?php endforeach; ?>
    </div>
</div>

</body>
</html>
