<?php
session_start();
require_once __DIR__ . '/../config/koneksi.php';

if (!isset($_SESSION['user'])) {
    header("Location: ../auth/login.php");
    exit;
}

$user_id = $_SESSION['user']['id'];

// Ambil ID keranjang & aksi
if (!isset($_GET['id']) || !isset($_GET['aksi'])) {
    header("Location: keranjang.php");
    exit;
}

$keranjang_id = intval($_GET['id']);
$aksi = $_GET['aksi'];

// Ambil data keranjang
$q = $koneksi->prepare("SELECT qty FROM keranjang WHERE id = ? AND user_id = ?");
$q->bind_param("ii", $keranjang_id, $user_id);
$q->execute();
$res = $q->get_result();

if ($res->num_rows == 0) {
    header("Location: keranjang.php");
    exit;
}

$keranjang = $res->fetch_assoc();
$qty = $keranjang['qty'];

// Aksi Plus / Minus
if ($aksi == "plus") {
    $qty++;
} elseif ($aksi == "minus") {
    if ($qty > 1) {
        $qty--;
    } else {
        // Jika qty = 1 dan dikurangi → otomatis hapus item
        $del = $koneksi->prepare("DELETE FROM keranjang WHERE id = ? AND user_id = ?");
        $del->bind_param("ii", $keranjang_id, $user_id);
        $del->execute();
        header("Location: keranjang.php");
        exit;
    }
}

// Update qty
$u = $koneksi->prepare("UPDATE keranjang SET qty = ? WHERE id = ? AND user_id = ?");
$u->bind_param("iii", $qty, $keranjang_id, $user_id);
$u->execute();

header("Location: keranjang.php");
exit;
?>
