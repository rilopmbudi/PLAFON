<?php
require_once "../config/koneksi.php";
session_start();

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'customer') {
    header("Location: ../auth/login.php");
    exit;
}

$user_id = $_SESSION['user']['id'];

// Ambil isi keranjang
$sql = "
    SELECT k.*, p.harga 
    FROM keranjang k
    JOIN produk p ON p.id = k.produk_id
    WHERE k.user_id = $user_id
";

$data = $koneksi->query($sql);

$total = 0;
$items = [];

while ($r = $data->fetch_assoc()) {
    $subtotal = $r['qty'] * $r['harga'];
    $total += $subtotal;
    $items[] = $r;
}

if (empty($items)) {
    die("Keranjang kosong, tidak bisa checkout");
}

// Mulai transaksi
$koneksi->begin_transaction();

try {

    // 1. Buat pesanan baru
    $stmt = $koneksi->prepare("INSERT INTO orders (user_id, total, tanggal) VALUES (?, ?, NOW())");
    $stmt->bind_param("id", $user_id, $total);
    $stmt->execute();
    $order_id = $stmt->insert_id;

    // 2. Masukkan semua produk ke order_items
    $stmt2 = $koneksi->prepare("
        INSERT INTO order_items (order_id, produk_id, harga, qty)
        VALUES (?, ?, ?, ?)
    ");

    foreach ($items as $i) {
        $stmt2->bind_param("iiii", $order_id, $i['produk_id'], $i['harga'], $i['qty']);
        $stmt2->execute();
    }

    // 3. Kosongkan keranjang
    $koneksi->query("DELETE FROM keranjang WHERE user_id = $user_id");

    // Commit transaksi
    $koneksi->commit();

} catch (Exception $e) {
    $koneksi->rollback();
    die("Checkout gagal: " . $e->getMessage());
}

?>
<!DOCTYPE html>
<html lang="id">
<head>
<title>Checkout Berhasil</title>
<style>
body { font-family: Arial; background:#f5f5f5; padding:20px; }
.box { 
    background:white; 
    padding:30px; 
    width:380px; 
    margin:auto; 
    border-radius:12px; 
    text-align:center; 
    box-shadow:0 4px 10px rgba(0,0,0,0.1);
}
h2 { color:#8B0000; }
a { 
    display:inline-block; 
    margin-top:15px; 
    padding:8px 15px; 
    background:#8B0000; 
    color:white; 
    border-radius:8px; 
    text-decoration:none; 
}
a:hover { background:#A30000; }
</style>
</head>
<body>

<div class="box">
    <h2>Checkout Berhasil</h2>
    <p>Pesanan kamu sudah dibuat ❤️</p>
    <p>Total Pembayaran: <b>Rp <?= number_format($total) ?></b></p>
    <a href="../orders/riwayat.php">Lihat Pesanan Saya</a>
</div>

</body>
</html>
