<?php
require_once __DIR__ . '/../config/koneksi.php';
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: ../auth/login.php");
    exit;
}

$id = intval($_GET['id'] ?? 0);

$query = $koneksi->query("SELECT * FROM produk WHERE id = $id");

if($query->num_rows == 0){
    die("Produk tidak ditemukan 😭");
}

$p = $query->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Detail Produk - <?= htmlspecialchars($p['nama']) ?></title>
<style>
body { font-family: Arial; background: #f5f5f5; padding: 20px; }
.container { max-width: 700px; margin:auto; background:#fff; padding:20px; border-radius:12px; box-shadow:0 0 10px rgba(0,0,0,0.1);}
h2 { color:#8B0000; margin-bottom:20px; text-align:center;}
.btn-back { display:inline-block; background:#8B0000; color:#fff; padding:8px 12px; border-radius:6px; text-decoration:none; margin-bottom:15px;}
.btn-back:hover { background:#5a0000; }
.img-prod { width:100%; max-width:300px; border-radius:8px; margin-bottom:15px; }
</style>
</head>
<body>
<div class="container">
    <a href="produk.php" class="btn-back"><i class="fas fa-arrow-left"></i> Kembali</a>
    <h2><?= htmlspecialchars($p['nama']) ?></h2>
    <img src="../uploads/<?= $p['gambar'] ?>" class="img-prod" alt="<?= htmlspecialchars($p['nama']) ?>">
    <p><strong>Harga:</strong> Rp <?= number_format($p['harga'],0,',','.') ?></p>
    <p><strong>Stok:</strong> <?= intval($p['stok']) ?></p>
    <p><strong>Deskripsi:</strong><br><?= nl2br(htmlspecialchars($p['deskripsi'])) ?></p>
</div>
</body>
</html>
