<?php
require_once __DIR__ . '/../config/koneksi.php';
session_start();

// Hanya customer
if(!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'customer'){
    header('Location: ../auth/login.php');
    exit;
}

// ==== CEK PRODUK KOSONG, MASUKKAN DUMMY ====
$resCount = $koneksi->query("SELECT COUNT(*) AS t FROM produk")->fetch_assoc()['t'];

if($resCount == 0){
    $dummy = [
        ['PLF-PVC-001','Plafon PVC Standard','PVC',15000,50],
        ['PLF-PVC-002','Plafon PVC Motif','PVC',18000,30],
        ['PLF-GYS-001','Plafon Gypsum Standard','Gypsum',20000,40],
        ['PLF-GYS-002','Plafon Gypsum Premium','Gypsum',35000,20],
        ['PLF-WOD-001','Plafon Kayu Natural','Kayu',40000,15],
        ['PLF-MET-001','Plafon Metal Minimalis','Metal',45000,10],
        ['PLF-GYS-003','Plafon Gypsum 3D','Gypsum',50000,25],
        ['PLF-PVC-003','Plafon PVC Anti Air','PVC',22000,35],
        ['PLF-WOD-002','Plafon Kayu Dark','Kayu',42000,12],
        ['PLF-MET-002','Plafon Metal Motif','Metal',48000,8],
    ];

    $stmt = $koneksi->prepare(
        "INSERT INTO produk (sku, nama, category, harga, stok) VALUES (?, ?, ?, ?, ?)"
    );

    foreach($dummy as $d){
        [$sku,$nama,$cat,$harga,$stok] = $d;
        $stmt->bind_param("sssdi", $sku,$nama,$cat,$harga,$stok);
        $stmt->execute();
    }
}

// Ambil semua produk
$res = $koneksi->query("SELECT * FROM produk ORDER BY id DESC");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>List Produk | Customer</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<style>
body{
    font-family: Arial, sans-serif;
    margin:0;
    background:#f4f4f4;
}

/* NAVBAR */
.navbar{
    width:100%;
    padding:15px 25px;
    background:#8B0000;
    color:#fff;
    display:flex;
    justify-content:space-between;
    align-items:center;
}
.navbar a{
    color:white;
    text-decoration:none;
    font-weight:bold;
}

/* Container */
.container{
    max-width:1100px;
    margin:25px auto;
    padding:10px;
}

h2{
    text-align:center;
    margin-bottom:20px;
    color:#8B0000;
}

/* Grid Produk */
.grid{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(250px,1fr));
    gap:20px;
}

/* CARD */
.card{
    background:white;
    padding:15px;
    border-radius:10px;
    box-shadow:0 4px 10px rgba(0,0,0,0.1);
    transition:0.3s;
}
.card:hover{
    transform:translateY(-5px);
}

/* Text */
.card h3{
    margin:5px 0;
    color:#333;
}
.card p{
    color:#666;
    font-size:14px;
}

.price{
    font-size:18px;
    font-weight:bold;
    color:#8B0000;
    margin-top:10px;
}

/* Tombol */
.btn{
    margin-top:12px;
    display:block;
    text-align:center;
    padding:10px;
    background:#28a745;
    color:white;
    border-radius:6px;
    text-decoration:none;
    font-weight:bold;
    transition:0.3s;
}
.btn:hover{
    opacity:0.9;
}
</style>

</head>
<body>

<!-- NAVBAR -->
<div class="navbar">
    <div><b>PLAFON KITA - Customer</b></div>
    <div>
        <a href="../dashboard/customer.php">Dashboard</a> |
        <a href="keranjang.php">Keranjang</a> |
        <a href="../auth/logout.php">Logout</a>
    </div>
</div>

<div class="container">
    <h2>Daftar Produk</h2>

    <div class="grid">

        <?php while($p = $res->fetch_assoc()): ?>
        <div class="card">
            <h3><?= htmlspecialchars($p['nama']) ?></h3>
            <p>Kategori: <b><?= htmlspecialchars($p['category']) ?></b></p>
            <p class="price">Rp <?= number_format($p['harga'],0,',','.') ?></p>
            <p>Stok: <?= $p['stok'] ?></p>

            <!-- FIX BAGIAN INI ❤️ -->
            <a class="btn" href="add_to_cart.php?id=<?= $p['id'] ?>">
                + Tambah ke Keranjang
            </a>
            <!-- END FIX -->

        </div>
        <?php endwhile; ?>

    </div>
</div>

</body>
</html>
