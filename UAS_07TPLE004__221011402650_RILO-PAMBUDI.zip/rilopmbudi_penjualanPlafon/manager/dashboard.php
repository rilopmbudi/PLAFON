<?php
require_once __DIR__ . '/../config/koneksi.php';
session_start();

// Cek login
if(!isset($_SESSION['user'])) header('Location: ../auth/login.php');

// Cek role Manager
if ($_SESSION['user']['role'] !== 'manager') {
    header("Location: ../auth/login.php");
    exit;
}

// Statistik
$totalProducts = $koneksi->query("SELECT COUNT(*) AS c FROM produk")->fetch_assoc()['c'] ?? 0;
$totalOrders = $koneksi->query("SELECT COUNT(*) AS c FROM orders")->fetch_assoc()['c'] ?? 0;
$totalPending = $koneksi->query("SELECT COUNT(*) AS c FROM orders WHERE status='pending'")->fetch_assoc()['c'] ?? 0;
$totalCustomers = $koneksi->query("SELECT COUNT(*) AS c FROM users WHERE role='customer'")->fetch_assoc()['c'] ?? 0;
?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Dashboard Manager</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
:root {
    --primary: #8B0000;
    --secondary: #FF6347;
    --bg: #f5f5f5;
    --card-bg: #fff;
    --text-dark: #333;
}
*{margin:0;padding:0;box-sizing:border-box;font-family:'Segoe UI',sans-serif}
body{background:var(--bg);display:flex;min-height:100vh;}
.sidebar{
    width:240px;background:var(--primary);color:#fff;position:fixed;height:100%;
    display:flex;flex-direction:column;align-items:center;padding-top:20px;transition:width 0.3s;
}
.sidebar h2{text-align:center;margin-bottom:30px;font-size:22px;letter-spacing:1px}
.sidebar a{
    display:flex;align-items:center;width:90%;padding:12px 15px;
    color:#fff;text-decoration:none;margin-bottom:10px;border-radius:8px;
    transition:0.3s;
}
.sidebar a:hover{background:var(--secondary);color:#fff;}
.sidebar a i{margin-right:10px;}
.content{margin-left:240px;padding:25px;flex:1}
.header{display:flex;justify-content:space-between;align-items:center;margin-bottom:25px;}
.header h1{color:var(--primary)}
.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:20px;margin-bottom:25px;}
.card{background:var(--card-bg);padding:20px;border-radius:12px;box-shadow:0 8px 20px rgba(0,0,0,0.08);transition:0.3s}
.card:hover{transform:translateY(-5px);}
.card h3{font-size:28px;color:var(--primary);margin-bottom:5px}
.card p{color:var(--text-dark);font-size:14px;}
.card .icon{font-size:30px;color:var(--secondary);margin-bottom:10px;transition:transform 0.3s;}
.card:hover .icon{transform:rotate(15deg);}
.welcome{margin-bottom:25px;}
.welcome h2{color:var(--primary);margin-bottom:8px;}
.welcome p{color:var(--text-dark);line-height:1.5;}
.btn-group a{
    display:inline-block;padding:10px 15px;margin-right:10px;
    border-radius:8px;text-decoration:none;color:#fff;background:var(--secondary);
    transition:0.3s;
}
.btn-group a:hover{background:var(--primary);}
@media(max-width:768px){.sidebar{width:200px}.content{margin-left:200px}}
@media(max-width:500px){.stats{grid-template-columns:1fr}}
</style>
</head>
<body>

<!-- SIDEBAR MANAGER -->
<div class="sidebar">
    <h2>PLAFON KITA</h2>

    <a href="#" class="active" onclick="return false;">
        <i class="fas fa-tachometer-alt"></i>Dashboard
    </a>


    <a href="laporan.php">
        <i class="fas fa-chart-line"></i>Laporan Penjualan
    </a>

    <a href="monitoring.php">
        <i class="fas fa-eye"></i>Monitoring Pesanan
    </a>

    <a href="karyawan.php">
        <i class="fas fa-users"></i>Data Karyawan
    </a>

    <a href="../auth/logout.php">
        <i class="fas fa-sign-out-alt"></i>Logout
    </a>
</div>


<div class="content">
    <div class="header">
        <h1>Dashboard Manager</h1>
        <span>Halo, <?= htmlspecialchars($_SESSION['user']['full_name']) ?></span>
    </div>

<div class="stats">
    <a href="produk.php" class="card" style="text-decoration:none; color:inherit;">
        <div class="icon"><i class="fas fa-box"></i></div>
        <h3><?= $totalProducts ?></h3>
        <p>Jumlah Produk</p>
    </a>

    <a href="orders.php" class="card" style="text-decoration:none; color:inherit;">
        <div class="icon"><i class="fas fa-receipt"></i></div>
        <h3><?= $totalOrders ?></h3>
        <p>Total Pesanan</p>
    </a>

    <a href="orders.php?status=pending" class="card" style="text-decoration:none; color:inherit;">
        <div class="icon"><i class="fas fa-bell"></i></div>
        <h3><?= $totalPending ?></h3>
        <p>Pesanan Pending</p>
    </a>

    <a href="customers.php" class="card" style="text-decoration:none; color:inherit;">
        <div class="icon"><i class="fas fa-users"></i></div>
        <h3><?= $totalCustomers ?></h3>
        <p>Total Customer</p>
    </a>
</div>

    <div class="welcome card">
        <h2>Selamat datang, <?= htmlspecialchars($_SESSION['user']['full_name']) ?></h2>
        <p>Anda login sebagai <b>Manager</b>. Anda dapat memantau laporan, melihat status pesanan, dan mengelola data karyawan.</p>
        <div class="btn-group">
            <a href="laporan.php">📊 Lihat Laporan</a>
            <a href="monitoring.php">📈 Monitoring Pesanan</a>
        </div>
    </div>
</div>

</body>
</html>
