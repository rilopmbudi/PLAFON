<?php
require_once __DIR__ . '/../config/koneksi.php';
session_start();
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'manager') {
    header("Location: ../auth/login.php");
    exit;
}

$sql = "
SELECT 
    o.id AS order_id,
    o.tanggal,
    o.status,
    u.full_name AS pelanggan,
    p.nama AS nama_produk,
    oi.qty,
    oi.harga
FROM orders o
JOIN users u ON o.user_id = u.id
JOIN order_items oi ON oi.order_id = o.id
JOIN produk p ON p.id = oi.produk_id
ORDER BY o.tanggal DESC
";

$data = $koneksi->query($sql);

if (!$data) {
    die("Query Error: " . $koneksi->error);
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Monitoring Pesanan - Manager</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
body { 
    font-family: Arial, sans-serif; 
    background: #f5f5f5; 
    display: flex;
    justify-content: center;
    padding-top: 20px;
}

.container { 
    width: 90%; 
    max-width: 1200px;
}

h1 { 
    color:#8B0000; 
    text-align: center;
    margin-bottom: 20px;
}

/* Tombol kembali panah kecil */
.back-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 35px;
    height: 35px;
    margin-bottom: 15px;
    background: #8B0000;
    color: white;
    border-radius: 50%;
    text-decoration: none;
    font-size: 16px;
    transition: 0.3s;
}
.back-btn:hover {
    background: #a30000;
    transform: translateX(-2px);
}

/* Table */
.table {
    width:100%;
    border-collapse: collapse;
    background:white;
    border-radius:10px;
    overflow:hidden;
    box-shadow:0 5px 15px rgba(0,0,0,0.1);
}
.table th {
    padding:12px;
    background:#8B0000;
    color:white;
}
.table td { 
    padding:10px; 
    border-bottom:1px solid #ddd; 
}
.table tr:hover { 
    background:#fff2f2; 
}

/* Badge warna status */
.badge { 
    padding:6px 10px; 
    font-size:12px; 
    border-radius:5px; 
    color:white; 
    font-weight: bold;
}
.pending { background:orange; }
.proses { background:blue; }
.selesai { background:green; }
.batal { background:red; }
</style>
</head>

<body>
<div class="container">

    <a href="dashboard.php" class="back-btn" title="Kembali ke Dashboard">
        <i class="fas fa-arrow-left"></i>
    </a>

    <h1><i class="fas fa-list"></i> Monitoring Semua Pesanan</h1>

    <table class="table">
        <tr>
            <th>ID</th>
            <th>Tanggal</th>
            <th>Pelanggan</th>
            <th>Produk</th>
            <th>Qty</th>
            <th>Subtotal</th>
            <th>Status</th>
        </tr>

        <?php if($data->num_rows > 0): ?>
            <?php while($d = $data->fetch_assoc()): ?>
            <tr>
                <td>#<?= $d['order_id'] ?></td>
                <td><?= $d['tanggal'] ?></td>
                <td><?= htmlspecialchars($d['pelanggan']) ?></td>
                <td><?= htmlspecialchars($d['nama_produk']) ?></td>
                <td><?= $d['qty'] ?></td>
                <td>Rp <?= number_format($d['qty'] * $d['harga'],0,',','.') ?></td>
                <td>
                    <span class="badge <?= strtolower($d['status']) ?>">
                        <?= strtoupper($d['status']) ?>
                    </span>
                </td>
            </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr>
                <td colspan="7" style="text-align:center;">Tidak ada pesanan</td>
            </tr>
        <?php endif; ?>
    </table>
</div>
</body>
</html>
