<?php
session_start();

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'manager') {
    header("Location: ../auth/login.php");
    exit;
}

// Redirect otomatis ke dashboard manager
header("Location: dashboard_manager.php");
exit;
?>
