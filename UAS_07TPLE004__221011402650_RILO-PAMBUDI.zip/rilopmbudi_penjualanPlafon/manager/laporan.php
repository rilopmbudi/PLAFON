<?php
require_once __DIR__ . '/../config/koneksi.php';
session_start();
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'manager') {
    header("Location: ../auth/login.php");
    exit;
}

$sql = "
SELECT 
    o.id AS order_id,
    o.tanggal,
    o.total,
    u.full_name AS pelanggan,
    p.nama AS nama_produk,
    oi.qty,
    oi.harga
FROM orders o
JOIN users u ON o.user_id = u.id
JOIN order_items oi ON oi.order_id = o.id
JOIN produk p ON p.id = oi.produk_id
WHERE o.status = 'selesai'
ORDER BY o.tanggal DESC
";

$laporan = $koneksi->query($sql);

if (!$laporan) {
    die("Query Error: " . $koneksi->error);
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Laporan Transaksi - Manager</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
body { 
    font-family: Arial, sans-serif; 
    background: #f5f5f5; 
}

.wrapper {
    width: 80%;
    margin: 30px auto;
}

.container-box {
    background: white;
    padding: 25px;
    border-radius: 12px;
    box-shadow: 0 5px 20px rgba(0,0,0,0.15);
}

h1 { 
    color: #8B0000; 
    margin-bottom: 20px;
    text-align: center;
}

.back-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 35px;
    height: 35px;
    margin-bottom: 15px;
    background: #8B0000;
    color: white;
    border-radius: 50%;
    text-decoration: none;
    font-size: 16px;
    transition: 0.3s;
}
.back-btn:hover {
    background: #a30000;
    transform: translateX(-2px);
}

/* Table */
.table {
    width: 100%;
    border-collapse: collapse;
}
.table th {
    background: #8B0000;
    color: white;
    padding: 12px;
}
.table td {
    padding: 10px;
    border-bottom: 1px solid #eee;
}
.table tr:hover {
    background: #fff3f3;
}
</style>
</head>

<body>
<div class="wrapper">
    <div class="container-box">

        <!-- Tombol kembali kecil -->
        <a href="dashboard.php" class="back-btn" title="Kembali ke Dashboard">
            <i class="fas fa-arrow-left"></i>
        </a>

        <h1><i class="fas fa-file-invoice"></i> Laporan Transaksi Selesai</h1>

        <table class="table">
            <tr>
                <th>ID</th>
                <th>Tanggal</th>
                <th>Pelanggan</th>
                <th>Produk</th>
                <th>Qty</th>
                <th>Subtotal</th>
                <th>Total Order</th>
            </tr>

            <?php if($laporan->num_rows > 0): ?>
                <?php while($d = $laporan->fetch_assoc()): ?>
                <tr>
                    <td>#<?= $d['order_id'] ?></td>
                    <td><?= $d['tanggal'] ?></td>
                    <td><?= htmlspecialchars($d['pelanggan']) ?></td>
                    <td><?= htmlspecialchars($d['nama_produk']) ?></td>
                    <td><?= $d['qty'] ?></td>
                    <td>Rp <?= number_format($d['qty'] * $d['harga'],0,',','.') ?></td>
                    <td><b>Rp <?= number_format($d['total'],0,',','.') ?></b></td>
                </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="7" style="text-align:center;">Tidak ada transaksi selesai</td>
                </tr>
            <?php endif; ?>
        </table>

    </div>
</div>
</body>
</html>
