<?php
require_once __DIR__ . '/../config/koneksi.php';
session_start();

// Cek login
if(!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'manager'){
    header('Location: ../auth/login.php');
    exit;
}

$sql = "SELECT id, full_name, username, created_at FROM users WHERE role='admin' ORDER BY created_at DESC";
$karyawan = $koneksi->query($sql);

if (!$karyawan) {
    die("Query Error: " . $koneksi->error);
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Data Admin - Manager</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
body {
    font-family: Arial, sans-serif;
    background: #f5f5f5;
    display: flex;
    justify-content: center;
    padding-top: 20px;
}

.container {
    width: 90%;
    max-width: 1000px;
}

h1 {
    color: #8B0000;
    text-align: center;
    margin-bottom: 20px;
}

/* Tombol kembali panah kecil */
.back-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 35px;
    height: 35px;
    margin-bottom: 15px;
    background: #8B0000;
    color: white;
    border-radius: 50%;
    text-decoration: none;
    font-size: 16px;
    transition: 0.3s;
}
.back-btn:hover {
    background: #a30000;
    transform: translateX(-2px);
}

/* Table */
.table {
    width: 100%;
    border-collapse: collapse;
    background: white;
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
}
.table th {
    padding: 12px;
    background: #8B0000;
    color: white;
}
.table td {
    padding: 10px;
    border-bottom: 1px solid #ddd;
}
.table tr:hover {
    background: #fff2f2;
}
</style>
</head>
<body>
<div class="container">

    <!-- Tombol kembali hanya panah -->
    <a href="dashboard.php" class="back-btn" title="Kembali ke Dashboard">
        <i class="fas fa-arrow-left"></i>
    </a>

    <h1><i class="fas fa-users"></i> Data Admin</h1>

    <table class="table">
        <tr>
            <th>ID</th>
            <th>Nama Lengkap</th>
            <th>Username</th>
            <th>Terdaftar</th>
        </tr>

        <?php if($karyawan->num_rows > 0): ?>
            <?php while($row = $karyawan->fetch_assoc()): ?>
                <tr>
                    <td>#<?= $row['id'] ?></td>
                    <td><?= htmlspecialchars($row['full_name']) ?></td>
                    <td><?= htmlspecialchars($row['username']) ?></td>
                    <td><?= date("d-m-Y H:i", strtotime($row['created_at'])) ?></td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr>
                <td colspan="4" style="text-align:center;">Tidak ada data admin</td>
            </tr>
        <?php endif; ?>
    </table>

</div>
</body>
</html>
