<?php
session_start();
require_once __DIR__ . '/../config/koneksi.php';

// Cek login customer
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'customer') {
    header("Location: ../auth/login.php");
    exit;
}

$user_id   = $_SESSION['user']['id'];
$produk_id = intval($_POST['produk_id']);
$jumlah    = intval($_POST['jumlah']);

// Cek input
if ($produk_id <= 0 || $jumlah <= 0) {
    header("Location: ../customer/produk.php?error=invalid");
    exit;
}

// Cek apakah produk ada
$cekProduk = $koneksi->query("SELECT * FROM produk WHERE id = $produk_id");
if ($cekProduk->num_rows == 0) {
    header("Location: ../customer/produk.php?error=notfound");
    exit;
}

// Cek jika sudah ada di keranjang → update qty
$cekKeranjang = $koneksi->query("
    SELECT * FROM keranjang 
    WHERE user_id = $user_id AND produk_id = $produk_id
");

if ($cekKeranjang->num_rows > 0) {
    // update qty
    $koneksi->query("
        UPDATE keranjang 
        SET qty = qty + $jumlah 
        WHERE user_id = $user_id AND produk_id = $produk_id
    ");
} else {
    // insert baru
    $koneksi->query("
        INSERT INTO keranjang (user_id, produk_id, qty)
        VALUES ($user_id, $produk_id, $jumlah)
    ");
}

header("Location: ../customer/keranjang.php?sukses=1");
exit;
