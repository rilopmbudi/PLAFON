<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: ../auth/login.php");
    exit;
}

$keranjang = $_SESSION['keranjang'] ?? [];
?>
<!DOCTYPE html>
<html>
<head>
<title>Keranjang</title>
<style>
body{font-family:Arial;background:#f5f5f5;padding:20px;}
.container{
    max-width:900px;margin:auto;background:white;padding:20px;
    border-radius:14px;box-shadow:0 0 10px rgba(0,0,0,0.1);
}
h2{color:#8B0000;text-align:center;}
.table{width:100%;border-collapse:collapse;margin-top:20px;}
.table th,.table td{border:1px solid #ddd;padding:12px;}
.table th{background:#8B0000;color:white;}
.btn{background:#8B0000;padding:8px 14px;color:white;border-radius:6px;text-decoration:none;}
</style>
</head>
<body>

<div class="container">
    <h2>Keranjang Belanja</h2>

    <table class="table">
        <tr>
            <th>No</th>
            <th>Produk</th>
            <th>Harga</th>
            <th>Qty</th>
        </tr>

        <?php $no=1; foreach($keranjang as $id => $item): ?>
        <tr>
            <td><?= $no++ ?></td>
            <td><?= $item['nama'] ?></td>
            <td>Rp <?= number_format($item['harga'],0,',','.') ?></td>
            <td><?= $item['qty'] ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
</div>

</body>
</html>
