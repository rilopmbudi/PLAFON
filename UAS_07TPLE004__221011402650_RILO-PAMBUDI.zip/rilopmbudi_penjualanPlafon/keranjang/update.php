<?php
require_once __DIR__ . '/../config/koneksi.php';
session_start();

$id = (int)$_GET['id'];
$aksi = $_GET['aksi'];

$q = $koneksi->query("SELECT qty FROM keranjang WHERE id=$id");
$data = $q->fetch_assoc();

if (!$data) die("Item tidak ditemukan!");

$qty = $data['qty'];

if ($aksi === "plus") {
    $qty++;
} elseif ($aksi === "minus") {
    $qty--;
    if ($qty < 1) $qty = 1;
}

$koneksi->query("UPDATE keranjang SET qty=$qty WHERE id=$id");

header("Location: index.php");
exit;
