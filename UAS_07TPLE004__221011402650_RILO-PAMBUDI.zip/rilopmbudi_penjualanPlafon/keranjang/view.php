<?php
require_once __DIR__ . '/../config/koneksi.php';
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: ../auth/login.php");
    exit;
}

$id = $_GET['id'] ?? 0;
$p = $koneksi->query("SELECT * FROM produk WHERE id=$id")->fetch_assoc();

if (!$p) {
    echo "Produk tidak ditemukan!";
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Detail Produk</title>
<style>
body{font-family:Arial;background:#f0f0f0;padding:30px;}
.box{
    max-width:700px;margin:auto;background:#fff;padding:20px;
    border-radius:12px;box-shadow:0 0 10px rgba(0,0,0,0.1);
}
h2{color:#8B0000;}
.btn{
    display:inline-block;margin-top:20px;padding:10px 15px;
    background:#8B0000;color:#fff;border-radius:8px;text-decoration:none;border:none;
    cursor:pointer;
}
.btn:hover{background:#5a0000;}
.success{
    background:#d4edda;color:#155724;padding:10px;margin-bottom:15px;
    border-radius:8px;border:1px solid #c3e6cb;
}
input, select{
    padding:8px;border-radius:6px;border:1px solid #ccc;
}
</style>
</head>
<body>

<div class="box">

    <?php if (isset($_GET['success'])): ?>
        <div class="success">Barang berhasil ditambahkan ke keranjang!</div>
    <?php endif; ?>

    <h2><?= $p['nama'] ?></h2>
    <p><b>Harga :</b> Rp <?= number_format($p['harga'],0,',','.') ?></p>
    <p><b>Stok :</b> <?= $p['stok'] ?></p>
    <p><b>Deskripsi :</b><br><?= nl2br($p['deskripsi']) ?></p>

    <form action="/PLAFON_COMPLETE/keranjang/add.php" method="POST">
        <input type="hidden" name="id" value="<?= $p['id'] ?>">

            <label><b>Pilih Jumlah Barang</b></label><br>
            <select name="qty" id="qty" onchange="toggleCustomQty()">
                <option value="1">1 Barang</option>
                <option value="2">2 Barang</option>
            <option value="3">3 Barang</option>
            <option value="custom">Custom</option>
        </select>

        <input type="number" name="qty_custom" id="qty_custom"
           placeholder="Masukkan jumlah..."
           style="display:none; margin-top:10px; width:200px;">

        <br><br>
        <button type="submit" class="btn">Tambah ke Keranjang</button>
    </form>

    <a href="list.php" class="btn" style="background:gray;">Kembali</a>
</div>

<script>
function toggleCustomQty() {
    let qty = document.getElementById('qty').value;
    let custom = document.getElementById('qty_custom');
    custom.style.display = qty === 'custom' ? 'block' : 'none';
}
</script>

</body>
</html>
