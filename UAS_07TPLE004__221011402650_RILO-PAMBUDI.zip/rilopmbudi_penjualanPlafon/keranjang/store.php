<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/../config/koneksi.php';
session_start();

// Cek login
if (!isset($_SESSION['user'])) {
    die("USER TIDAK LOGIN");
}

$user_id = $_SESSION['user']['id'];
$produk_id = isset($_POST['id']) ? (int) $_POST['id'] : 0;

if ($produk_id <= 0) {
    die("ID PRODUK TIDAK VALID");
}

// CEK apakah produk sudah ada di keranjang
$cek = $koneksi->prepare("SELECT id, qty FROM keranjang WHERE user_id = ? AND produk_id = ?");
$cek->bind_param("ii", $user_id, $produk_id);
$cek->execute();
$hasil = $cek->get_result()->fetch_assoc();

if ($hasil) {
    // UPDATE qty + 1
    $update = $koneksi->prepare("UPDATE keranjang SET qty = qty + 1 WHERE id = ?");
    $update->bind_param("i", $hasil['id']);
    $update->execute();
} else {
    // INSERT baru
    $insert = $koneksi->prepare("INSERT INTO keranjang (user_id, produk_id, qty) VALUES (?, ?, 1)");
    $insert->bind_param("ii", $user_id, $produk_id);
    $insert->execute();
}

// Setelah berhasil arahkan ke keranjang
header("Location: index.php");
exit;
?>
