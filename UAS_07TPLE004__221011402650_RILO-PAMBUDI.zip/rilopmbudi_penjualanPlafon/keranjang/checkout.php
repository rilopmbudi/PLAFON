<?php
require_once __DIR__ . '/../config/koneksi.php';
session_start();

$user_id = $_SESSION['user']['id'];

$q = $koneksi->query("
    SELECT k.*, p.harga 
    FROM keranjang k
    JOIN produk p ON k.produk_id = p.id
    WHERE k.user_id=$user_id
");

$total = 0;
while ($r = $q->fetch_assoc()) {
    $total += $r['qty'] * $r['harga'];
}

$koneksi->query("INSERT INTO orders (user_id, total, status) VALUES ($user_id, $total, 'pending')");
$order_id = $koneksi->insert_id;

$q2 = $koneksi->query("
    SELECT k.*, p.harga 
    FROM keranjang k
    JOIN produk p ON k.produk_id = p.id
    WHERE k.user_id=$user_id
");

while ($d = $q2->fetch_assoc()) {
    $koneksi->query("
        INSERT INTO order_items (order_id, produk_id, harga, qty)
        VALUES ($order_id, {$d['produk_id']}, {$d['harga']}, {$d['qty']})
    ");
}

$koneksi->query("DELETE FROM keranjang WHERE user_id=$user_id");

echo "<script>alert('Checkout berhasil!');window.location='../customer/dashboard.php';</script>";
