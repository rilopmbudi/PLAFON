<?php
require_once __DIR__ . '/../config/koneksi.php';
session_start();

$user_id = $_SESSION['user']['id'];

$koneksi->query("DELETE FROM keranjang WHERE user_id=$user_id");

header("Location: index.php");
exit;
