<?php
require_once __DIR__ . '/../config/koneksi.php';
session_start();

$id = (int)$_GET['id'];
$koneksi->query("DELETE FROM keranjang WHERE id=$id");

header("Location: index.php");
exit;
