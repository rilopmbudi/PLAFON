<?php
require_once __DIR__ . '/../config/koneksi.php';
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: ../auth/login.php");
    exit;
}

$user_id = $_SESSION['user']['id'];

$q = $koneksi->prepare("
    SELECT k.*, p.nama, p.harga 
    FROM keranjang k
    JOIN produk p ON k.produk_id = p.id
    WHERE k.user_id = ?
");
$q->bind_param("i", $user_id);
$q->execute();
$result = $q->get_result();
?>
<!DOCTYPE html>
<html>
<head>
<title>Keranjang</title>
<style>
body{font-family:Arial;background:#f5f5f5;padding:20px;}
.box{
    max-width:900px;margin:auto;background:#fff;padding:20px;
    border-radius:12px;box-shadow:0 0 10px rgba(0,0,0,0.1);
    position: relative;
}

/* Tombol panah kiri */
.back-btn{
    position:absolute;
    left:15px;
    top:15px;
    font-size:20px;
    background:#8B0000;
    color:white;
    padding:8px 12px;
    border-radius:8px;
    text-decoration:none;
}
.back-btn:hover{
    background:#5e0000;
}

h2{text-align:center;color:#8B0000;margin-top:10px;}
table{width:100%;border-collapse:collapse;margin-top:20px;}
th,td{padding:12px;border:1px solid #ddd;}
th{background:#8B0000;color:#fff;}
.btn{
    background:#8B0000;color:white;padding:8px 12px;
    border-radius:8px;text-decoration:none;
}
.btn-sm{
    padding:5px 8px;font-size:12px;
}
.btn-danger{background:#d9534f;}
.btn-warning{background:#f0ad4e;}
.btn-success{background:#5cb85c;}
.actions{
    display:flex;gap:6px;justify-content:center;
}
</style>
</head>
<body>

<div class="box">

    <!-- Tombol kembali -->
    <a href="../produk/list.php" class="back-btn">&#8592;</a>

    <h2>Keranjang Belanja</h2>

    <table>
        <tr>
            <th>Nama Produk</th>
            <th>Qty</th>
            <th>Subtotal</th>
            <th>Aksi</th>
        </tr>

        <?php
        $total = 0;

        if ($result->num_rows === 0) {
            echo "<tr><td colspan='4' style='text-align:center;'>Keranjang masih kosong</td></tr>";
        } else {
            while ($i = $result->fetch_assoc()):
                $sub = $i['qty'] * $i['harga'];
                $total += $sub;
        ?>
        <tr>
            <td><?= $i['nama'] ?></td>

            <td>
                <div style="display:flex;align-items:center;gap:6px;">
                    <a href="update.php?id=<?= $i['id'] ?>&aksi=minus" class="btn btn-sm btn-warning">-</a>
                    <?= $i['qty'] ?>
                    <a href="update.php?id=<?= $i['id'] ?>&aksi=plus" class="btn btn-sm btn-success">+</a>
                </div>
            </td>

            <td>Rp <?= number_format($sub, 0, ',', '.') ?></td>

            <td class="actions">
                <a href="delete.php?id=<?= $i['id'] ?>" class="btn btn-sm btn-danger"
                   onclick="return confirm('Hapus item ini?')">Hapus</a>
            </td>
        </tr>
        <?php endwhile; } ?>
    </table>

    <h3>Total: Rp <?= number_format($total, 0, ',', '.') ?></h3>

    <?php if ($total > 0): ?>
        <a href="checkout.php" class="btn">Checkout</a>
        <a href="clear.php" class="btn btn-danger" style="float:right;"
           onclick="return confirm('Hapus semua isi keranjang?')">Hapus Semua</a>
    <?php endif; ?>

</div>

</body>
</html>
